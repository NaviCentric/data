# Pratt Miller VES/STS QE Automation Framework

Business Object-Centric automation framework supporting Web, Desktop, API, and Database validation through a unified automation platform.

## Project Structure

```
qe-framework/
├── core/                          # Framework core services
│   ├── config/                   # Configuration management
│   ├── infrastructure/           # Base infrastructure & fixtures
│   ├── logger/                   # Logging utilities
│   └── utils/                    # Utility functions
├── data-management/              # Layer 2: Data Factory, Seek, Prerequisites
├── validation/                   # Cross-cutting validation layer
├── domain/                        # Business Objects Layer
│   └── models/                   # Domain models (Project, Outing, Vehicle, Channel, etc.)
├── components/                    # Execution Components Layer (Layer 4)
│   ├── web/
│   │   └── ves2/                 # VES2 Web UI (Playwright)
│   │       ├── pages/           # Page Objects
│   │       └── fragments/       # Reusable Wijmo UI fragments
│   ├── desktop/
│   │   └── sts/                  # STS2 Desktop UI (FlaUI)
│   │       ├── screens/         # Screen Models
│   │       └── fragments/       # Reusable DevExpress component wrappers
│   ├── api/
│   │   ├── ves2/                 # VES2 API (Playwright API Testing)
│   │   │   ├── clients/         # Service clients per business entity
│   │   │   ├── builders/        # Fluent request payload builders
│   │   │   └── contracts/       # API request/response contracts (OpenAPI)
│   │   └── sts/                  # STS2 API (Playwright API Testing)
│   │       ├── clients/         # Service clients per business entity
│   │       ├── builders/        # Fluent request payload builders
│   │       └── contracts/       # API request/response contracts (OpenAPI)
│   ├── database/                 # Database (SQL Server) — shared across both apps
│   │   ├── repositories/        # Repository implementations per entity
│   │   ├── queries/             # Parameterized T-SQL query definitions
│   │   └── procedures/          # Stored procedure wrappers
│   └── factory/                  # Component composition root
│       ├── ComponentFactory.ts  # Top-level factory (ui + api + db + desktop)
│       ├── UiFactory.ts         # VES2 pages & Wijmo fragments
│       ├── ApiFactory.ts        # VES2 + STS clients & builders
│       ├── DbFactory.ts         # Database repositories
│       └── DesktopFactory.ts    # STS screens & DevExpress fragments
├── tests/                         # Test Layer
│   ├── fixtures/                 # Playwright fixtures & helpers
│   ├── category-a/               # Automation-owned tests (independent)
│   └── category-b/               # Environment-owned workflow tests
├── documentation/                 # Architecture & Strategy docs
├── playwright.config.ts          # Playwright configuration
├── package.json                  # Dependencies & scripts
└── tsconfig.json                 # TypeScript configuration
```

## Architecture Overview

### 5-Layer Architecture

1. **Tests Layer** - Automated test suites (Category A & B)
2. **Data Management Layer** - Root-level `data-management/` services
3. **Business Objects Layer** - Domain models (VES2: Project/Outing/Vehicle; STS: Channel/Activity/Workflow)
4. **Execution Components Layer** - Web UI (VES2), Desktop UI (STS), API (VES2 + STS), Database (shared)
5. **Technology Foundation** - Playwright, FlaUI (Desktop), SQL Server

### Cross-Cutting Services

- **Validation Layer** - Root-level `validation/` centralized validators
- **Reporting & Observability** - HTML reports, traces, screenshots
- **Configuration & Infrastructure** - Environment config, dependency injection, utilities

### Application Namespaces

| Namespace | Component | Entities |
|-----------|-----------|----------|
| `ves2`    | Web UI, API | Project, OutingGroup, Outing, Vehicle, Assembly, Part |
| `sts`     | Desktop UI, API | Channel, Activity, Workflow |
| *(shared)*| Database | All entities via repositories |

Tests access everything through the unified `components` fixture:

```typescript
// VES2 — API & Web
components.api.ves2.clients.project
components.api.ves2.clients.outing
components.ui.pages.projects
components.ui.pages.outing

// STS — API & Desktop
components.api.sts.clients.channel
components.api.sts.clients.workflow
components.desktop.screens.channels
components.desktop.screens.workflows

// Shared Database
components.db.repositories.project
components.db.repositories.part
```

## Naming Conventions

### Files & Folders

| Artifact | Convention | Example |
|----------|-----------|---------|
| Folders | `camelCase` | `data-management/`, `ves2/`, `sts/` |
| TypeScript source files | `PascalCase` | `ChannelClient.ts`, `ProjectsPage.ts` |
| Test spec files | `kebab-case.spec.ts` | `parts.spec.ts`, `outings.spec.ts` |
| Fixture files | `camelCase.fixtures.ts` | `categoryA.fixtures.ts` |
| Index files | `index.ts` (always lowercase) | `index.ts` |

### TypeScript

| Artifact | Convention | Example |
|----------|-----------|---------|
| Classes | `PascalCase` | `ChannelClient`, `WorkflowsScreen`, `WijmoGridFragment` |
| Interfaces | `PascalCase` | `Channel`, `ApiListResponse`, `StsBusinessContext` |
| Type aliases | `PascalCase` | `EntityStatus` |
| Functions & methods | `camelCase` | `getById()`, `fromDomainModel()`, `waitForLoad()` |
| Private class fields | `camelCase` | `baseUrl`, `apiContext` |
| Constants | `camelCase` (instances) / `SCREAMING_SNAKE_CASE` (true constants) | `config`, `logger` / `DB_HOST` |
| Enums | `PascalCase` members | `EntityStatus = 'Active'` |

### Domain Models

| Artifact | Convention | Example |
|----------|-----------|---------|
| Entity interfaces | `PascalCase`, no suffix | `Channel`, `Workflow`, `Project` |
| Type guard functions | `is` + `PascalCase` | `isChannel()`, `isProject()` |
| Context aggregates | `PascalCase` + `Context` | `StsBusinessContext`, `BusinessContext` |
| ID fields | entity name + `Id` (camelCase) | `channelId`, `outingGroupId` |

### API Layer (`components/api/`)

| Artifact | Convention | Example |
|----------|-----------|---------|
| Client classes | `PascalCase` + `Client` | `ChannelClient`, `ProjectClient` |
| Builder classes | `PascalCase` + `RequestBuilder` | `ChannelRequestBuilder`, `OutingRequestBuilder` |
| Request contracts | `Create/Update` + entity + `Request` | `CreateChannelRequest`, `UpdateWorkflowRequest` |
| Response contracts | entity + `Response` | `ChannelResponse`, `ActivityResponse` |
| List wrappers | `ApiListResponse<T>` | `ApiListResponse<ChannelResponse>` |

### Web Layer (`components/web/ves2/`)

| Artifact | Convention | Example |
|----------|-----------|---------|
| Page object classes | `PascalCase` + `Page` | `ProjectsPage`, `LoginPage`, `OutingPage` |
| Base page | `BasePage` (abstract) | `BasePage` |
| Wijmo fragment classes | `Wijmo` + component + `Fragment` | `WijmoGridFragment`, `WijmoComboFragment` |
| Route paths | `kebab-case` string | `'/outing-groups'`, `'/login'` |

### Desktop Layer (`components/desktop/sts/`)

| Artifact | Convention | Example |
|----------|-----------|---------|
| Screen model classes | `PascalCase` + `Screen` (except main entry) | `ChannelsScreen`, `WorkflowsScreen` |
| Main entry screen | `MainWindow` | `MainWindow` |
| DevExpress fragment classes | `DevExpress` + component + `Fragment` | `DevExpressGridFragment`, `DevExpressTabFragment` |
| Automation IDs | `PascalCase` strings matching WinForms names | `'ChannelsGridControl'`, `'MainNavigationTabs'` |

### Database Layer (`components/database/`)

| Artifact | Convention | Example |
|----------|-----------|---------|
| Repository classes | `PascalCase` + `Repository` | `ChannelRepository`, `ProjectRepository` |
| Query constant objects | `PascalCase` entity + `Queries` | `ChannelQueries`, `ProjectQueries` |
| Stored procedure wrappers | `exec` + `PascalCase` + `Proc` | `execCreateChannelProc` |

### Factories & Fixtures

| Artifact | Convention | Example |
|----------|-----------|---------|
| Factory classes | `PascalCase` + `Factory` | `ComponentFactory`, `ApiFactory` |
| Factory output interfaces | `PascalCase` + component scope | `Ves2ApiComponents`, `StsApiClients` |
| Fixture files | `camelCase.fixtures.ts` | `component.fixture.ts` |
| Fixture variable exposed to tests | `components` | `{ components }` |

### Suggested Improvements

> These are areas where consistency could be tightened as the framework grows:

1. **Repository classes for STS** — `ChannelRepository`, `ActivityRepository`, `WorkflowRepository` should be added to `components/database/` to mirror the VES2 repositories already present.
2. **Validation classes** — Currently only VES2 entities have validators. STS validators (`ChannelValidator`, `ActivityValidator`) should follow the same `PascalCase` + `Validator` suffix pattern.
3. **Fixture scope** — `categoryA.fixtures.ts` and `categoryB.fixtures.ts` still import from `data-management` and `validation` directly. Consider consolidating all fixture access through the `component.fixture.ts` to keep the single-entry-point pattern consistent.
4. **`data-management` kebab folder** — All other folders use camelCase. Consider renaming to `dataManagement` for consistency, or document the exception explicitly.
5. **Client method naming** — VES2 clients use `getByAssembly()`, `getByProject()` etc. STS clients currently only have `getAll()` / `getByChannel()`. Aim for consistent query method names: `getAll()`, `getById()`, `getBy{Relationship}()`, `create()`, `deleteById()`.

## Prerequisites

- Node.js 18+
- npm or yarn
- SQL Server (for database validation)
- Git

## Installation

```bash
# Clone repository
git clone <repository-url>
cd qe-framework

# Install dependencies
npm install

# Install Playwright browsers
# NODE_USE_SYSTEM_CA=1 is required on corporate networks so that Playwright
# trusts the system certificate store (avoids SSL cert errors when downloading browsers)
NODE_USE_SYSTEM_CA=1 npx playwright install

# Setup environment
cp .env.example .env
# Edit .env with your environment values
```

> **Corporate / On-Premise Environments**: If your machine is behind a corporate proxy or uses a custom root CA, always prefix Playwright browser installs with `NODE_USE_SYSTEM_CA=1`. Without it, browser downloads fail with certificate trust errors. You can also add it permanently to your `.env` file:
> ```
> NODE_USE_SYSTEM_CA=1
> ```

## Configuration

### Environment Variables

Copy `.env.example` to `.env` and update with your environment details:

```bash
cp .env.example .env
```

Key variables:
- `BASE_URL` - VES2 web application URL
- `API_BASE_URL` - VES2 API base URL
- `STS_API_BASE_URL` - STS2 API base URL
- `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` - Database connection
- `NODE_USE_SYSTEM_CA` - Set to `1` on corporate networks (SSL trust)

## Running Tests

```bash
# Run all tests
npm test

# Run Category A tests (automation-owned)
npm run test:category-a

# Run Category B tests (environment-owned)
npm run test:category-b

# Run with UI
npm run test:ui

# Run in debug mode
npm run test:debug

# Run headed (visible browser)
npm run test:headed

# View test report
npm run report
```

## Test Classification

### Category A - Automation-Owned Tests

Independent, repeatable tests that create and manage their own data.

```
tests/category-a/
└── parts.spec.ts              # VES2 Part CRUD operations
```

**Characteristics:**
- Self-contained
- Creates own data
- Cleans up after execution
- Environment independent
- Suitable for CI/CD pipelines

### Category B - Environment-Owned Workflow Tests

Tests that utilize existing production-representative business data.

```
tests/category-b/
└── outings.spec.ts            # VES2 Outing workflow tests
```

**Characteristics:**
- Leverages existing business entities
- Validates realistic workflows
- Requires production-refreshed environments
- Uses Data Seek for runtime discovery

## Development

### Build TypeScript

```bash
npm run build
```

### Lint & Format

```bash
# Lint all TypeScript files (includes Playwright rules for test files)
npm run lint

# Format all TypeScript, JSON, and Markdown files
npm run format
```

### Clean Build Artifacts

```bash
npm run clean
```

## CI/CD Integration

### Jenkins Pipeline

Tests are executed via Jenkins pipeline defined in `Jenkinsfile`.

Pipeline stages:
1. **Setup** - Install dependencies, validate environment
2. **Build** - Compile TypeScript
3. **Test** - Execute test suites
4. **Report** - Generate test reports
5. **Cleanup** - Archive artifacts

> Ensure `NODE_USE_SYSTEM_CA=1` is set in the Jenkins agent environment when running `npx playwright install` in the pipeline.

Trigger the pipeline after deployment to execute Category A and Category B tests.

## Framework Principles

1. **Business Object-Centric** - Automation organized around business entities, not UI controls
2. **Data-Driven** - Prioritizes data complexity over UI complexity
3. **API-First Validation** - Validates through API/Database before UI
4. **Layered Architecture** - Clear separation of concerns across layers
5. **Reusability** - Business objects consumed across all layers

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Web UI (VES2) | Playwright |
| Desktop UI (STS) | FlaUI |
| APIs (VES2 + STS) | Playwright API Testing |
| Database | SQL Server / T-SQL |
| Test Runner | Playwright Test |
| Language | TypeScript |
| Linting | ESLint + @typescript-eslint + eslint-plugin-playwright |
| Formatting | Prettier |
| Source Control | Git |
| CI/CD | Jenkins |

## Documentation

- [Framework Architecture](documentation/architecture/framework-architecture.md)
- [Test Automation Strategy](documentation/strategy/test-automation-strategy.md)
- [Architecture Diagram](documentation/architecture/pratt-miller-framework-architecture.drawio)

## Contributing

Follow these guidelines when contributing:

1. Maintain business object-centric design principles
2. Place logic in appropriate layer and application namespace (`ves2` or `sts`)
3. Use TypeScript strict mode
4. Follow naming conventions documented above
5. Add tests for new components
6. Run `npm run lint` and `npm run build` before committing

## Support

For questions or issues, contact the QE team.

## License

Proprietary - Pratt Miller

---

## Phase Status

| Phase | Status | Description |
|-------|--------|-------------|
| Phase 1 | ✅ Complete | Framework skeleton, structure, base classes, fixtures, sample tests, CI/CD pipeline |
| Phase 2 | ✅ Complete | Page objects, API clients (VES2 + STS), database repositories, validation layer, factories, ESLint + Prettier |
| Phase 3 | 🔜 Next | Full test scenario coverage, STS database repositories, additional validators |


## Architecture Overview

- Node.js 18+
- npm or yarn
- SQL Server (for database validation)
- Git

## Installation

```bash
# Clone repository
git clone <repository-url>
cd qe-framework

# Install dependencies
npm install

# Install Playwright browsers
npx playwright install

# Setup environment
cp .env.example .env
# Edit .env with your environment values
```

## Configuration

### Environment Variables

Copy `.env.example` to `.env` and update with your environment details:

```bash
cp .env.example .env
```

Key variables:
- `BASE_URL` - Web application URL
- `API_BASE_URL` - API endpoint
- `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME` - Database connection

## Running Tests

```bash
# Run all tests
npm test

# Run Category A tests (automation-owned)
npm run test:category-a

# Run Category B tests (environment-owned)
npm run test:category-b

# Run with UI
npm run test:ui

# Run in debug mode
npm run test:debug

# Run headed (visible browser)
npm run test:headed

# View test report
npm run report
```

## Test Classification

### Category A - Automation-Owned Tests

Independent, repeatable tests that create and manage their own data.

```
tests/category-a/
└── parts.spec.ts              # Part CRUD operations
```

**Characteristics:**
- Self-contained
- Creates own data
- Cleans up after execution
- Environment independent
- Suitable for CI/CD pipelines

### Category B - Environment-Owned Workflow Tests

Tests that utilize existing production-representative business data.

```
tests/category-b/
└── outings.spec.ts            # Outing workflow tests
```

**Characteristics:**
- Leverages existing business entities
- Validates realistic workflows
- Requires production-refreshed environments
- Uses Data Seek for runtime discovery

## Development

### Build TypeScript

```bash
npm run build
```

### Lint & Format

```bash
npm run lint
npm run format
```

### Clean Build Artifacts

```bash
npm run clean
```

## CI/CD Integration

### Jenkins Pipeline

Tests are executed via Jenkins pipeline defined in `Jenkinsfile`.

Pipeline stages:
1. **Setup** - Install dependencies, validate environment
2. **Build** - Compile TypeScript
3. **Test** - Execute test suites
4. **Report** - Generate test reports
5. **Cleanup** - Archive artifacts

Trigger the pipeline after deployment to execute Category A and Category B tests.

## Framework Principles

1. **Business Object-Centric** - Automation organized around business entities, not UI controls
2. **Data-Driven** - Prioritizes data complexity over UI complexity
3. **API-First Validation** - Validates through API/Database before UI
4. **Layered Architecture** - Clear separation of concerns across layers
5. **Reusability** - Business objects consumed across all layers

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Web UI | Playwright |
| Desktop UI | FlaUI |
| APIs | Playwright API Testing |
| Database | SQL Server / T-SQL |
| Test Runner | Playwright Test |
| Language | TypeScript |
| Source Control | Git |
| CI/CD | Jenkins |

## Documentation

- [Framework Architecture](documentation/architecture/framework-architecture.md)
- [Test Automation Strategy](documentation/strategy/test-automation-strategy.md)
- [Architecture Diagram](documentation/architecture/pratt-miller-framework-architecture.drawio)

## Contributing

Follow these guidelines when contributing:

1. Maintain business object-centric design principles
2. Place logic in appropriate layer
3. Use TypeScript strict mode
4. Add tests for new components
5. Update documentation

## Support

For questions or issues, contact the QE team.

## License

Proprietary - Pratt Miller

---

## Phase Status

| Phase | Status | Description |
|-------|--------|-------------|
| Phase 1 | ✅ Complete | Framework skeleton, structure, base classes, fixtures, sample tests, CI/CD pipeline |
| Phase 2 | 🔜 Next | Page objects, API clients, database repositories, full test scenarios |
