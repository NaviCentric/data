/**
 * Index file for quick reference of all framework modules
 * This file serves as an entry point to understand the framework structure
 */

// Core Infrastructure
export * as config from './core/config/index.js';
export * as logger from './core/logger/index.js';
export * as infrastructure from './core/infrastructure/index.js';
export * as utils from './core/utils/index.js';

// Domain Models
export * as models from './domain/models/index.js';

// Data Management (Layer 2)
export * from './data-management/index.js';

// Components - Layer 4 Execution Components (organized by technology)
export * as web from './components/web/index.js';
export * as desktop from './components/desktop/index.js';
export * as api from './components/api/index.js';
export * from './components/database/index.js';

// Cross-Cutting Services
export * from './validation/index.js';

// Factories
export * from './components/factory/index.js';

// Test Fixtures
export * as componentFixtures from './tests/fixtures/component.fixture.js';
export * as componentsFixtures from './tests/fixtures/components.fixture.js';
export * as dataProviderFixtures from './tests/fixtures/dataprovider.fixture.js';
export * as validatorFixtures from './tests/fixtures/validator.fixture.js';
export * as composedFixtures from './tests/fixtures/composed.fixture.js';
