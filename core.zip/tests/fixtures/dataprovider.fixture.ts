/**
 * Data provider fixture
 * Provides category-aware data access utilities and DB connectivity.
 */

import { test as base } from '../../core/infrastructure/index.js';
import type { APIRequestContext } from '@playwright/test';
import { DataPrerequisiteValidator, DataSeekService, TestDataFactory } from '../../data-management/index.js';
import { DatabaseRepository } from '../../components/database/index.js';

export type TestOwnershipCategory = 'automation-owned' | 'environment-owned';

export interface CategoryDataProvider {
  forCategory(category: TestOwnershipCategory): TestDataFactory | DataSeekService;
  testDataFactory: TestDataFactory;
  dataSeekService: DataSeekService;
}

export interface DataProviderFixture {
  dataProvider: CategoryDataProvider;
  testDataFactory: TestDataFactory;
  dataSeekService: DataSeekService;
  prerequisiteValidator: DataPrerequisiteValidator;
  database: DatabaseRepository;
}

export const dataProviderFixtures = {
  dataProvider: async (
    { request }: { request: APIRequestContext },
    use: (value: CategoryDataProvider) => Promise<void>,
  ): Promise<void> => {
    const testDataFactory = new TestDataFactory(request);
    const dataSeekService = new DataSeekService();

    const dataProvider: CategoryDataProvider = {
      forCategory: (category) =>
        category === 'automation-owned' ? testDataFactory : dataSeekService,
      testDataFactory,
      dataSeekService,
    };

    await use(dataProvider);
  },

  testDataFactory: async (
    { request }: { request: APIRequestContext },
    use: (value: TestDataFactory) => Promise<void>,
  ): Promise<void> => {
    const factory = new TestDataFactory(request);
    await use(factory);
  },

  dataSeekService: async (_fixtures: unknown, use: (value: DataSeekService) => Promise<void>): Promise<void> => {
    const service = new DataSeekService();
    await use(service);
  },

  prerequisiteValidator: async (
    _fixtures: unknown,
    use: (value: DataPrerequisiteValidator) => Promise<void>,
  ): Promise<void> => {
    const validator = new DataPrerequisiteValidator();
    await use(validator);
  },

  database: async (_fixtures: unknown, use: (value: DatabaseRepository) => Promise<void>): Promise<void> => {
    const db = new DatabaseRepository();
    const isValid = await db.validateConnection();
    if (!isValid) {
      throw new Error('Database connection failed');
    }

    await use(db);
    await db.closeConnection();
  },
};

export const dataProviderTest = base.extend<DataProviderFixture>(dataProviderFixtures);
