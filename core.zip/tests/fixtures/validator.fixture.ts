/**
 * Validator fixture
 * Provides VES2 and STS validation utilities.
 */

import { test as base } from '../../core/infrastructure/index.js';
import {
  ActivityValidator,
  AssemblyValidator,
  ChannelValidator,
  OutingValidator,
  PartValidator,
  ProjectValidator,
  VehicleValidator,
  WorkflowValidator,
} from '../../validation/index.js';

export interface ValidatorFixture {
  projectValidator: ProjectValidator;
  partValidator: PartValidator;
  vehicleValidator: VehicleValidator;
  outingValidator: OutingValidator;
  assemblyValidator: AssemblyValidator;
  channelValidator: ChannelValidator;
  activityValidator: ActivityValidator;
  workflowValidator: WorkflowValidator;
}

export const validatorFixtures = {
  projectValidator: async (_fixtures: unknown, use: (value: ProjectValidator) => Promise<void>): Promise<void> => {
    await use(new ProjectValidator());
  },

  partValidator: async (_fixtures: unknown, use: (value: PartValidator) => Promise<void>): Promise<void> => {
    await use(new PartValidator());
  },

  vehicleValidator: async (_fixtures: unknown, use: (value: VehicleValidator) => Promise<void>): Promise<void> => {
    await use(new VehicleValidator());
  },

  outingValidator: async (_fixtures: unknown, use: (value: OutingValidator) => Promise<void>): Promise<void> => {
    await use(new OutingValidator());
  },

  assemblyValidator: async (_fixtures: unknown, use: (value: AssemblyValidator) => Promise<void>): Promise<void> => {
    await use(new AssemblyValidator());
  },

  channelValidator: async (_fixtures: unknown, use: (value: ChannelValidator) => Promise<void>): Promise<void> => {
    await use(new ChannelValidator());
  },

  activityValidator: async (_fixtures: unknown, use: (value: ActivityValidator) => Promise<void>): Promise<void> => {
    await use(new ActivityValidator());
  },

  workflowValidator: async (_fixtures: unknown, use: (value: WorkflowValidator) => Promise<void>): Promise<void> => {
    await use(new WorkflowValidator());
  },
};

export const validatorTest = base.extend<ValidatorFixture>(validatorFixtures);
