/**
 * Composed fixtures
 * Combines components + data provider + validators for ergonomic test authoring.
 */

import { expect, test as base } from '../../core/infrastructure/index.js';
import { componentsFixtures, type ComponentsFixture } from './components.fixture.js';
import { dataProviderFixtures, type DataProviderFixture } from './dataprovider.fixture.js';
import { validatorFixtures, type ValidatorFixture } from './validator.fixture.js';

export type AppComposedFixture = ComponentsFixture & DataProviderFixture & ValidatorFixture;

const appFixtureConfig = {
  ...componentsFixtures,
  ...dataProviderFixtures,
  ...validatorFixtures,
};

const appTest = base.extend<AppComposedFixture>(appFixtureConfig);

export const ves2AutomationTest = appTest;
export const ves2EnvironmentTest = appTest;
export const stsAutomationTest = appTest;
export const stsEnvironmentTest = appTest;

// Backward-compatible aliases for legacy category naming.
export const categoryATest = ves2AutomationTest;
export const categoryBTest = ves2EnvironmentTest;

export { expect };
