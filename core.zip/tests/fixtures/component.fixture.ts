/**
 * Compatibility fixture exports
 * Kept for existing imports while the framework transitions to split fixtures.
 */

export { componentsTest as componentTest, expect } from './components.fixture.js';
export {
  ves2AutomationTest,
  ves2EnvironmentTest,
  stsAutomationTest,
  stsEnvironmentTest,
  categoryATest,
  categoryBTest,
} from './composed.fixture.js';
export { dataProviderTest } from './dataprovider.fixture.js';
export { validatorTest } from './validator.fixture.js';
