/**
 * Components fixture
 * Provides execution components only (UI/API/Desktop/DB adapters via factory).
 */

import { expect, test as base } from '../../core/infrastructure/index.js';
import type { APIRequestContext, Page } from '@playwright/test';
import { ComponentFactory, type ComponentSuite } from '../../components/factory/index.js';

export interface ComponentsFixture {
  components: ComponentSuite;
}

export const componentsFixtures = {
  components: async (
    { page, request }: { page: Page; request: APIRequestContext },
    use: (value: ComponentSuite) => Promise<void>,
  ): Promise<void> => {
    const factory = new ComponentFactory(page, request);
    await use(factory.create());
  },
};

export const componentsTest = base.extend<ComponentsFixture>(componentsFixtures);

export { expect };
