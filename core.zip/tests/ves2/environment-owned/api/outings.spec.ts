/**
 * VES2 Environment-Owned — Outing Workflow Tests — REFERENCE EXAMPLE
 *
 * Environment-owned tests: use existing production-representative data.
 */

import { ves2EnvironmentTest as test, expect } from '../../../fixtures/composed.fixture.js';

test.describe('VES2 Environment-Owned — Outing Workflow', () => {
  test('navigate the project -> outing group -> outing hierarchy', async ({
    dataSeekService,
    prerequisiteValidator,
    outingValidator,
    logger,
  }) => {
    logger.info('Checking environment prerequisites');
    const ready = await prerequisiteValidator.validateOutingsExist();
    test.skip(!ready, 'No active outings found in environment - skipping');

    const projects = await dataSeekService.findActiveProjects();
    expect(projects.length).toBeGreaterThan(0);
    const project = projects[0];
    logger.info(`Using project: ${project.id} - ${project.name}`);

    const groups = await dataSeekService.findOutingGroupsByProject(project.id!);
    expect(groups.length).toBeGreaterThan(0);

    const outings = await dataSeekService.findEligibleOutings(groups[0].id!);
    expect(outings.length).toBeGreaterThan(0);
    const outing = outings[0];
    logger.info(`Using outing: ${outing.id} - ${outing.name}`);

    await outingValidator.validateExists(outing);
    outingValidator.validateFields(outing, { status: 'Active' });
  });

  test('validate vehicle assembly workflow', async ({
    dataSeekService,
    prerequisiteValidator,
    vehicleValidator,
    assemblyValidator,
    logger,
  }) => {
    const ready = await prerequisiteValidator.validateVehiclesExist();
    test.skip(!ready, 'No vehicles found in environment - skipping');

    void dataSeekService;
    void vehicleValidator;
    void assemblyValidator;
    void logger;
  });
});
