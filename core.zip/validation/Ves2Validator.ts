/**
 * VES2 Validation Layer
 * Validators for VES2 entities: Project, Outing, Vehicle, Assembly, Part
 */

import { expect } from '@playwright/test';
import { logger } from '../core/logger/index.js';
import type { Assembly, Outing, Part, Project, Vehicle } from '../domain/models/index.js';
import { AssemblyRepository } from '../components/database/repositories/PartRepository.js';
import { OutingRepository } from '../components/database/repositories/OutingRepository.js';
import { PartRepository } from '../components/database/repositories/PartRepository.js';
import { ProjectRepository } from '../components/database/repositories/ProjectRepository.js';
import { VehicleRepository } from '../components/database/repositories/VehicleRepository.js';

export abstract class BaseValidator {
  protected logger = logger;
  constructor(protected entityName: string) {}

  protected assertDefined<T>(value: T | undefined | null, label: string): asserts value is T {
    expect(value).toBeDefined();
    expect(value).not.toBeNull();
    void label;
  }

  protected assertEqual<T>(actual: T, expected: T, label: string): void {
    expect(actual, `${this.entityName}.${label} mismatch`).toBe(expected);
  }
}

export class ProjectValidator extends BaseValidator {
  private repo = new ProjectRepository();
  constructor() { super('Project'); }
  async validateCreated(project: Project): Promise<void> {
    this.assertDefined(project.id, 'id');
    expect(await this.repo.exists(project.id!)).toBe(true);
  }
  validateFields(project: Project, expected: Partial<Project>): void {
    if (expected.name !== undefined) this.assertEqual(project.name, expected.name, 'name');
    if (expected.status !== undefined) this.assertEqual(project.status, expected.status, 'status');
  }
}

export class PartValidator extends BaseValidator {
  private repo = new PartRepository();
  constructor() { super('Part'); }
  async validateCreated(part: Part): Promise<void> {
    this.assertDefined(part.id, 'id');
    expect(await this.repo.exists(part.id!)).toBe(true);
  }
  validateFields(part: Part, expected: Partial<Part>): void {
    if (expected.name !== undefined) this.assertEqual(part.name, expected.name, 'name');
    if (expected.partNumber !== undefined) this.assertEqual(part.partNumber, expected.partNumber, 'partNumber');
  }
}

export class VehicleValidator extends BaseValidator {
  private repo = new VehicleRepository();
  constructor() { super('Vehicle'); }
  async validateExists(vehicle: Vehicle): Promise<void> {
    this.assertDefined(vehicle.id, 'id');
    expect(await this.repo.exists(vehicle.id!)).toBe(true);
  }
  validateFields(vehicle: Vehicle, expected: Partial<Vehicle>): void {
    if (expected.vin !== undefined) this.assertEqual(vehicle.vin, expected.vin, 'vin');
    if (expected.make !== undefined) this.assertEqual(vehicle.make, expected.make, 'make');
    if (expected.model !== undefined) this.assertEqual(vehicle.model, expected.model, 'model');
    if (expected.year !== undefined) this.assertEqual(vehicle.year, expected.year, 'year');
  }
}

export class OutingValidator extends BaseValidator {
  private repo = new OutingRepository();
  constructor() { super('Outing'); }
  async validateExists(outing: Outing): Promise<void> {
    this.assertDefined(outing.id, 'id');
    expect(await this.repo.exists(outing.id!)).toBe(true);
  }
  validateFields(outing: Outing, expected: Partial<Outing>): void {
    if (expected.name !== undefined) this.assertEqual(outing.name, expected.name, 'name');
    if (expected.status !== undefined) this.assertEqual(outing.status, expected.status, 'status');
  }
}

export class AssemblyValidator extends BaseValidator {
  private repo = new AssemblyRepository();
  constructor() { super('Assembly'); }
  async validateExists(assembly: Assembly): Promise<void> {
    this.assertDefined(assembly.id, 'id');
    expect(await this.repo.exists(assembly.id!)).toBe(true);
  }
  validateFields(assembly: Assembly, expected: Partial<Assembly>): void {
    if (expected.name !== undefined) this.assertEqual(assembly.name, expected.name, 'name');
    if (expected.status !== undefined) this.assertEqual(assembly.status, expected.status, 'status');
  }
}
