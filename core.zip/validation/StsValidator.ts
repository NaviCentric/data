/**
 * STS Validation Layer
 * Validators for STS entities: Channel, Activity, Workflow
 */

import { expect } from '@playwright/test';
import { logger } from '../core/logger/index.js';
import type { Channel, Activity, Workflow } from '../domain/models/index.js';

export abstract class BaseStsValidator {
  protected logger = logger;
  constructor(protected entityName: string) {}

  protected assertDefined<T>(value: T | undefined | null, label: string): asserts value is T {
    expect(value).toBeDefined();
    expect(value).not.toBeNull();
    void label;
  }

  protected assertEqual<T>(actual: T, expected: T, label: string): void {
    expect(actual, `${this.entityName}.${label} mismatch`).toBe(expected);
  }
}

export class ChannelValidator extends BaseStsValidator {
  constructor() { super('Channel'); }
  
  async validateCreated(channel: Channel): Promise<void> {
    this.assertDefined(channel.id, 'id');
    // TODO: Add repository when STS database repositories are created
  }

  validateFields(channel: Channel, expected: Partial<Channel>): void {
    if (expected.name !== undefined) this.assertEqual(channel.name, expected.name, 'name');
    if (expected.channelType !== undefined) this.assertEqual(channel.channelType, expected.channelType, 'channelType');
    if (expected.status !== undefined) this.assertEqual(channel.status, expected.status, 'status');
  }
}

export class ActivityValidator extends BaseStsValidator {
  constructor() { super('Activity'); }
  
  async validateCreated(activity: Activity): Promise<void> {
    this.assertDefined(activity.id, 'id');
    // TODO: Add repository when STS database repositories are created
  }

  validateFields(activity: Activity, expected: Partial<Activity>): void {
    if (expected.name !== undefined) this.assertEqual(activity.name, expected.name, 'name');
    if (expected.activityType !== undefined) this.assertEqual(activity.activityType, expected.activityType, 'activityType');
    if (expected.channelId !== undefined) this.assertEqual(activity.channelId, expected.channelId, 'channelId');
    if (expected.status !== undefined) this.assertEqual(activity.status, expected.status, 'status');
  }
}

export class WorkflowValidator extends BaseStsValidator {
  constructor() { super('Workflow'); }
  
  async validateCreated(workflow: Workflow): Promise<void> {
    this.assertDefined(workflow.id, 'id');
    // TODO: Add repository when STS database repositories are created
  }

  validateFields(workflow: Workflow, expected: Partial<Workflow>): void {
    if (expected.name !== undefined) this.assertEqual(workflow.name, expected.name, 'name');
    if (expected.version !== undefined) this.assertEqual(workflow.version, expected.version, 'version');
    if (expected.status !== undefined) this.assertEqual(workflow.status, expected.status, 'status');
  }
}
