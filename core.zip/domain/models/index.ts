/**
 * Business Object Models — Layer 3
 *
 * Domain models representing VES/STS business entities.
 * These are the central abstraction used across all layers:
 *   Web UI  |  Desktop UI  |  API  |  Database  |  Data Management
 *
 * Business Hierarchy:
 *   Project → OutingGroup → Outing → Vehicle → Assembly → Part → Attributes
 */

// ─────────────────────────────────────────────────────────────────────────────
// Shared
// ─────────────────────────────────────────────────────────────────────────────

export type EntityStatus = 'Active' | 'Inactive' | 'Pending' | 'Archived';

export interface BaseEntity {
  id?: string;
  status?: EntityStatus;
  createdAt?: Date;
  updatedAt?: Date;
}

// ─────────────────────────────────────────────────────────────────────────────
// Project
// ─────────────────────────────────────────────────────────────────────────────

export interface Project extends BaseEntity {
  name: string;
  description?: string;
  outingGroups?: OutingGroup[];
}

export function isProject(value: unknown): value is Project {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Project).name === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Outing Group
// ─────────────────────────────────────────────────────────────────────────────

export interface OutingGroup extends BaseEntity {
  projectId: string;
  name: string;
  description?: string;
  outings?: Outing[];
}

export function isOutingGroup(value: unknown): value is OutingGroup {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as OutingGroup).projectId === 'string' &&
    typeof (value as OutingGroup).name === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Outing
// ─────────────────────────────────────────────────────────────────────────────

export interface Outing extends BaseEntity {
  outingGroupId: string;
  name: string;
  description?: string;
  startDate?: Date;
  endDate?: Date;
  vehicles?: Vehicle[];
}

export function isOuting(value: unknown): value is Outing {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Outing).outingGroupId === 'string' &&
    typeof (value as Outing).name === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Vehicle
// ─────────────────────────────────────────────────────────────────────────────

export interface Vehicle extends BaseEntity {
  outingId: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  assemblies?: Assembly[];
}

export function isVehicle(value: unknown): value is Vehicle {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Vehicle).vin === 'string' &&
    typeof (value as Vehicle).make === 'string' &&
    typeof (value as Vehicle).model === 'string' &&
    typeof (value as Vehicle).year === 'number'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Assembly
// ─────────────────────────────────────────────────────────────────────────────

export interface Assembly extends BaseEntity {
  vehicleId: string;
  name: string;
  description?: string;
  parts?: Part[];
  attributes?: AssemblyAttribute[];
}

export function isAssembly(value: unknown): value is Assembly {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Assembly).vehicleId === 'string' &&
    typeof (value as Assembly).name === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Part
// ─────────────────────────────────────────────────────────────────────────────

export interface Part extends BaseEntity {
  assemblyId: string;
  name: string;
  partNumber: string;
  description?: string;
  attributes?: PartAttribute[];
}

export function isPart(value: unknown): value is Part {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Part).assemblyId === 'string' &&
    typeof (value as Part).name === 'string' &&
    typeof (value as Part).partNumber === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Attributes
// ─────────────────────────────────────────────────────────────────────────────

export interface PartAttribute {
  id?: string;
  partId: string;
  attributeName: string;
  attributeValue: string;
}

export interface AssemblyAttribute {
  id?: string;
  assemblyId: string;
  attributeName: string;
  attributeValue: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// STS — Channel
// ─────────────────────────────────────────────────────────────────────────────

export interface Channel extends BaseEntity {
  name: string;
  description?: string;
  channelType: string;
  activities?: Activity[];
}

export function isChannel(value: unknown): value is Channel {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Channel).name === 'string' &&
    typeof (value as Channel).channelType === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STS — Activity
// ─────────────────────────────────────────────────────────────────────────────

export interface Activity extends BaseEntity {
  channelId: string;
  name: string;
  description?: string;
  activityType: string;
  sequenceOrder?: number;
}

export function isActivity(value: unknown): value is Activity {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Activity).channelId === 'string' &&
    typeof (value as Activity).name === 'string' &&
    typeof (value as Activity).activityType === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STS — Workflow
// ─────────────────────────────────────────────────────────────────────────────

export interface Workflow extends BaseEntity {
  name: string;
  description?: string;
  version?: string;
  activities?: WorkflowActivity[];
}

export interface WorkflowActivity {
  id?: string;
  workflowId: string;
  activityId: string;
  stepOrder: number;
  activity?: Activity;
}

export function isWorkflow(value: unknown): value is Workflow {
  return (
    typeof value === 'object' &&
    value !== null &&
    typeof (value as Workflow).name === 'string'
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// VES2 Hierarchy helper type
// ─────────────────────────────────────────────────────────────────────────────

export interface BusinessContext {
  project?: Project;
  outingGroup?: OutingGroup;
  outing?: Outing;
  vehicle?: Vehicle;
  assembly?: Assembly;
  part?: Part;
}

// ─────────────────────────────────────────────────────────────────────────────
// STS Hierarchy helper type
// ─────────────────────────────────────────────────────────────────────────────

export interface StsBusinessContext {
  channel?: Channel;
  activity?: Activity;
  workflow?: Workflow;
}
