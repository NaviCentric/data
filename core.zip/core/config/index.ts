/**
 * Core Configuration Module
 * Centralizes application and environment configuration
 */

import dotenv from 'dotenv';
import path from 'path';

// Load environment variables
dotenv.config();

export const config = {
  // Environment
  nodeEnv: process.env['NODE_ENV'] || 'development',
  ci: process.env['CI'] === 'true',

  // URLs
  baseUrl: process.env['BASE_URL'] || 'http://localhost:3000',
  apiBaseUrl: process.env['API_BASE_URL'] || 'http://localhost:5000',

  // Database Configuration (Placeholder - localhost)
  database: {
    host: process.env['DB_HOST'] || 'localhost',
    port: parseInt(process.env['DB_PORT'] || '1433', 10),
    user: process.env['DB_USER'] || 'sa',
    password: process.env['DB_PASSWORD'] || '',
    database: process.env['DB_NAME'] || 'VES_STS_Dev',
    timeout: parseInt(process.env['DB_TIMEOUT'] || '30000', 10),
  },

  // Logging
  logging: {
    level: process.env['LOG_LEVEL'] || 'info',
    dir: path.resolve(process.env['LOG_DIR'] || './logs'),
  },

  // Testing
  testing: {
    timeout: parseInt(process.env['TEST_TIMEOUT'] || '30000', 10),
    screenshotOnFailure: process.env['SCREENSHOT_ON_FAILURE'] !== 'false',
    videoOnFailure: process.env['VIDEO_ON_FAILURE'] !== 'false',
  },

  // Jenkins/CI
  jenkins: {
    buildNumber: process.env['BUILD_NUMBER'] || '',
    buildId: process.env['BUILD_ID'] || '',
    gitBranch: process.env['GIT_BRANCH'] || '',
    gitCommit: process.env['GIT_COMMIT'] || '',
  },
};

export default config;
