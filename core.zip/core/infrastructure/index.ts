/**
 * Infrastructure & Base Fixtures
 * Provides base classes and fixtures for test infrastructure
 */

import { test as base, expect } from '@playwright/test';
import { logger } from '../logger/index.js';
import { config } from '../config/index.js';

/**
 * Extended test fixture with framework utilities
 */
export const test = base.extend<{ logger: typeof logger; config: typeof config }>({
  logger: async (fixtures, use: (value: typeof logger) => Promise<void>) => {
    void fixtures;
    logger.info('Test started');
    await use(logger);
    logger.info('Test completed');
  },

  config: async (fixtures, use: (value: typeof config) => Promise<void>) => {
    void fixtures;
    await use(config);
  },
});

export { expect };

/**
 * Base fixture for business object automation
 */
export interface BusinessObjectFixture {
  logger: typeof logger;
  config: typeof config;
}
