/**
 * Logger Configuration
 * Centralized logging using Winston
 */

import winston from 'winston';
import path from 'path';
import { config } from '../config/index.js';

const logDir = config.logging.dir;

const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

export const logger = winston.createLogger({
  level: config.logging.level,
  format: logFormat,
  defaultMeta: { service: 'qe-framework' },
  transports: [
    // Console output
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.printf((info: Record<string, unknown>): string => {
          const level = String(info.level);
          const message = String(info.message);
          const timestamp = String(info.timestamp);
          return `${timestamp} [${level}]: ${message}`;
        })
      ),
    }),
    // File output
    new winston.transports.File({
      filename: path.join(logDir, 'error.log'),
      level: 'error',
    }),
    new winston.transports.File({
      filename: path.join(logDir, 'combined.log'),
    }),
  ],
});

export default logger;
