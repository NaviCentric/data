/**
 * Data Prerequisite Validation Service
 * Validates environment readiness before Category B test execution.
 */

import { logger } from '../core/logger/index.js';
import { DataSeekService } from './DataSeekService.js';

export class DataPrerequisiteValidator {
  private seekService = new DataSeekService();

  async validateProjectsExist(): Promise<boolean> {
    const projects = await this.seekService.findActiveProjects();
    const valid = projects.length > 0;
    if (!valid) logger.warn('Prerequisite FAILED: no active projects found');
    return valid;
  }

  async validateOutingsExist(projectId?: string): Promise<boolean> {
    if (!projectId) {
      const projects = await this.seekService.findActiveProjects();
      if (projects.length === 0) return false;
      projectId = projects[0].id!;
    }

    const groups = await this.seekService.findOutingGroupsByProject(projectId);
    if (groups.length === 0) return false;

    const outings = await this.seekService.findEligibleOutings(groups[0].id!);
    const valid = outings.length > 0;
    if (!valid) logger.warn('Prerequisite FAILED: no active outings found');
    return valid;
  }

  async validateVehiclesExist(): Promise<boolean> {
    const projects = await this.seekService.findActiveProjects();
    if (projects.length === 0) return false;

    const groups = await this.seekService.findOutingGroupsByProject(projects[0].id!);
    if (groups.length === 0) return false;

    const outings = await this.seekService.findEligibleOutings(groups[0].id!);
    if (outings.length === 0) return false;

    const vehicles = await this.seekService.findVehiclesForOuting(outings[0].id!);
    const valid = vehicles.length > 0;
    if (!valid) logger.warn('Prerequisite FAILED: no vehicles found');
    return valid;
  }

  async validateAssembliesExist(vehicleId?: string): Promise<boolean> {
    if (!vehicleId) {
      const projects = await this.seekService.findActiveProjects();
      if (projects.length === 0) return false;

      const groups = await this.seekService.findOutingGroupsByProject(projects[0].id!);
      if (groups.length === 0) return false;

      const outings = await this.seekService.findEligibleOutings(groups[0].id!);
      if (outings.length === 0) return false;

      const vehicles = await this.seekService.findVehiclesForOuting(outings[0].id!);
      if (vehicles.length === 0) return false;
      vehicleId = vehicles[0].id!;
    }

    const assemblies = await this.seekService.findAssembliesForVehicle(vehicleId);
    const valid = assemblies.length > 0;
    if (!valid) logger.warn(`Prerequisite FAILED: no assemblies found for vehicle ${vehicleId}`);
    return valid;
  }

  async validateAll(): Promise<boolean> {
    const checks = [
      { name: 'Projects', fn: () => this.validateProjectsExist() },
      { name: 'Outings', fn: () => this.validateOutingsExist() },
      { name: 'Vehicles', fn: () => this.validateVehiclesExist() },
      { name: 'Assemblies', fn: () => this.validateAssembliesExist() },
    ];

    for (const check of checks) {
      const passed = await check.fn();
      if (!passed) {
        logger.warn(`Environment certification FAILED at: ${check.name}`);
        return false;
      }
    }

    return true;
  }
}

export default DataPrerequisiteValidator;
