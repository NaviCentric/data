/**
 * Data Seek Service
 * Locates suitable business data at runtime for Category B tests.
 */

import { logger } from '../core/logger/index.js';
import { ProjectRepository } from '../components/database/repositories/ProjectRepository.js';
import { OutingGroupRepository, OutingRepository } from '../components/database/repositories/OutingRepository.js';
import { VehicleRepository } from '../components/database/repositories/VehicleRepository.js';
import { AssemblyRepository } from '../components/database/repositories/PartRepository.js';
import type { Project, OutingGroup, Outing, Vehicle, Assembly } from '../domain/models/index.js';

export class DataSeekService {
  private projectRepo = new ProjectRepository();
  private outingGroupRepo = new OutingGroupRepository();
  private outingRepo = new OutingRepository();
  private vehicleRepo = new VehicleRepository();
  private assemblyRepo = new AssemblyRepository();

  async findActiveProjects(): Promise<Project[]> {
    logger.info('DataSeekService: seeking active projects');
    return this.projectRepo.findActive();
  }

  async findOutingGroupsByProject(projectId: string): Promise<OutingGroup[]> {
    logger.info(`DataSeekService: seeking outing groups for project ${projectId}`);
    return this.outingGroupRepo.findByProject(projectId);
  }

  async findEligibleOutings(outingGroupId: string): Promise<Outing[]> {
    logger.info(`DataSeekService: seeking outings for group ${outingGroupId}`);
    return this.outingRepo.findByOutingGroup(outingGroupId);
  }

  async findVehiclesForOuting(outingId: string): Promise<Vehicle[]> {
    logger.info(`DataSeekService: seeking vehicles for outing ${outingId}`);
    return this.vehicleRepo.findByOuting(outingId);
  }

  async findAssembliesForVehicle(vehicleId: string): Promise<Assembly[]> {
    logger.info(`DataSeekService: seeking assemblies for vehicle ${vehicleId}`);
    return this.assemblyRepo.findByVehicle(vehicleId);
  }
}

export default DataSeekService;
