/**
 * Test Data Factory — Adapter Pattern
 * Creates business data through the most appropriate available mechanism.
 *
 * Priority order:
 *   1. API
 *   2. Database
 *   3. UI
 */

import type { APIRequestContext } from '@playwright/test';
import { logger } from '../core/logger/index.js';
import { PartClient } from '../components/api/ves2/clients/PartClient.js';
import { ProjectClient } from '../components/api/ves2/clients/ProjectClient.js';
import { ProjectRequestBuilder, PartRequestBuilder } from '../components/api/ves2/builders/RequestBuilders.js';
import { ProjectRepository } from '../components/database/repositories/ProjectRepository.js';
import { PartRepository } from '../components/database/repositories/PartRepository.js';
import type { Project, Part } from '../domain/models/index.js';

export class TestDataFactory {
  constructor(private apiContext?: APIRequestContext) {}

  async createProject(projectData: Omit<Project, 'id'>): Promise<Project> {
    logger.info(`TestDataFactory: creating project "${projectData.name}"`);

    if (this.apiContext) {
      try {
        const client = new ProjectClient(this.apiContext);
        const request = new ProjectRequestBuilder().fromDomainModel(projectData as Project).build();
        return await client.create(request);
      } catch (err) {
        logger.warn(`API project creation failed, falling back to DB: ${String(err)}`);
      }
    }

    void new ProjectRepository();
    return { ...projectData, id: `stub-${Date.now()}` };
  }

  async cleanupProject(id: string): Promise<void> {
    if (id.startsWith('stub-')) return;
    if (!this.apiContext) return;

    try {
      const client = new ProjectClient(this.apiContext);
      await client.deleteById(id);
    } catch (err) {
      logger.warn(`Project cleanup failed: ${String(err)}`);
    }
  }

  async createPart(partData: Omit<Part, 'id'>): Promise<Part> {
    logger.info(`TestDataFactory: creating part "${partData.name}"`);

    if (this.apiContext) {
      try {
        const client = new PartClient(this.apiContext);
        const request = new PartRequestBuilder().fromDomainModel(partData as Part).build();
        return await client.create(request);
      } catch (err) {
        logger.warn(`API part creation failed, falling back to DB: ${String(err)}`);
      }
    }

    void new PartRepository();
    return { ...partData, id: `stub-${Date.now()}` };
  }

  async cleanupPart(id: string): Promise<void> {
    if (id.startsWith('stub-')) return;
    if (!this.apiContext) return;

    try {
      const client = new PartClient(this.apiContext);
      await client.deleteById(id);
    } catch (err) {
      logger.warn(`Part cleanup failed: ${String(err)}`);
    }
  }

  async cleanup(entityId: string, entityType: string): Promise<void> {
    switch (entityType.toLowerCase()) {
      case 'project':
        await this.cleanupProject(entityId);
        break;
      case 'part':
        await this.cleanupPart(entityId);
        break;
      default:
        logger.warn(`TestDataFactory: no cleanup handler for ${entityType}`);
    }
  }
}

export default TestDataFactory;
