# Pratt Miller VES/STS Automation Framework Architecture

## Overview

The Pratt Miller VES/STS Automation Framework is designed as a business object-centric automation architecture supporting Web, Desktop, API, and Database validation through a unified automation platform.

The framework has been designed specifically to address the complexity of the VES/STS ecosystem, where business workflows depend heavily on interconnected entities such as Projects, Outing Groups, Outings, Vehicles, Assemblies, Parts, and their associated attributes.

Rather than organizing automation around user interfaces or individual technologies, the framework is organized around business entities and business workflows. This approach improves maintainability, reduces duplication, and allows the same business concepts to be reused across Web, Desktop, API, and Database automation layers.

---

# Architectural Principles

The framework is built upon the following principles:

## Business Object-Centric Design

Business entities are the center of the framework.

Examples include:

* Project
* Outing Group
* Outing
* Vehicle
* Assembly
* Part
* Part Attribute
* Assembly Attribute

All automation layers interact with these objects rather than directly manipulating UI controls, API payloads, or database structures.

This allows tests to be written in business language rather than technical implementation details.

---

## Data-Driven Automation

The framework acknowledges that the primary challenge within VES/STS is data complexity rather than UI complexity.

Automation is therefore designed around:

* Test data creation
* Runtime data discovery
* Environment readiness validation
* Business object population

before any execution activities occur.

---

## API-First Validation

Whenever suitable interfaces are available, validation should occur through APIs and database checks before relying on user interface validation.

This provides:

* Faster execution
* Better reliability
* Reduced maintenance
* Improved root cause analysis

UI automation remains important for validating user workflows and application behavior but should not be the sole validation mechanism.

---

# Framework Architecture

The framework is composed of five primary layers:

1. Tests
2. Data Management
3. Business Objects
4. Execution Components
5. Technology Foundation

In addition, several cross-cutting services support all layers:

* Validation Layer
* Reporting & Observability
* Configuration & Infrastructure

---

# Layer 1 – Tests

The top layer represents the automation suites executed by the framework.

The framework currently supports the following test classifications:

## Category A – Entity-Owned Tests

Category A tests are fully independent.

Characteristics:

* Create their own data
* Own the data lifecycle
* Clean up after execution
* Environment independent

Examples:

* Create Part
* Add Part History
* Create User Table Entry
* CRUD Validation

These tests are intended to provide reliable and repeatable validation.

---

## Category B – Environment-Owned Tests

Category B tests leverage existing business data available within production-refreshed environments.

Characteristics:

* Utilize existing business entities
* Validate realistic workflows
* Depend on runtime data availability
* Execute against production-representative datasets

Examples:

* Outing workflows
* Vehicle workflows
* Assembly workflows
* Project-level business processes

These tests provide realistic business coverage without requiring complex data creation.

---

## Cross-Layer Tests

Additional automation may validate complete workflows across multiple layers.

Examples:

* UI + API validation
* API + Database validation
* UI + API + Database validation

---

# Layer 2 – Data Management

Data Management is responsible for supplying valid business objects to the framework.

This layer executes before any business workflow begins.

Its responsibility is to either:

* Create data
* Locate data
* Validate environment readiness

The output of this layer is a populated Business Object.

---

## Test Data Factory

The Test Data Factory implements an Adapter Pattern.

Its purpose is to create business data through the most appropriate available mechanism.

Supported creation methods include:

* API
* Database
* UI

Example:

If an API exists for creating a Part, the factory will utilize the API.

If no API exists, the framework may create data through database seeding.

If neither is available, the framework may create data through the user interface.

This abstraction allows tests to remain independent of the underlying creation mechanism.

---

## Data Seek Service

The Data Seek Service is primarily used by Category B tests.

Its responsibility is to locate suitable business data at runtime.

Examples:

* Find active Projects
* Find eligible Outings
* Find linked Assemblies
* Find valid Vehicles

This approach avoids:

* Hardcoded identifiers
* Environment-specific dependencies
* Brittle automation

---

## Data Prerequisite Validation

Before Category B execution begins, prerequisite checks are performed.

Examples:

* Required Project exists
* Required Outing exists
* Vehicle exists
* Assembly data exists

If prerequisites are not satisfied:

* Test execution is skipped
* Diagnostic information is reported
* False failures are prevented

This process serves as environment certification.

---

# Layer 3 – Business Objects

Business Objects represent the canonical business model of the application.

They are the central abstraction used throughout the framework.

Examples include:

* Project
* Outing Group
* Outing
* Vehicle
* Assembly
* Part
* Part Attribute
* Assembly Attribute

Business Objects encapsulate business data and provide a common language across all automation layers.

A single Vehicle object may be:

* Created through APIs
* Queried through SQL
* Displayed in the UI
* Validated through multiple layers

while remaining represented by the same domain object.

This significantly reduces duplication and improves maintainability.

---

## Business Object Relationships

The framework models the primary business hierarchy as:

Project → Outing Group → Outing → Vehicle → Assembly → Parts → Attributes

This hierarchy influences:

* Data Seek operations
* Data Prerequisite validation
* Business workflow execution
* End-to-end validation

---

# Layer 4 – Execution Components

Execution Components perform actual interactions with the application.

These components translate Business Objects into actions.

---

## Web UI Components

Implemented using Playwright.

Responsibilities include:

* Page Objects
* Reusable UI Fragments
* User interactions
* Browser-based validation

---

## Desktop UI Components

Implemented using FlaUI.

Responsibilities include:

* Screen models
* DevExpress interaction wrappers
* Desktop workflow execution
* WPF application interaction

---

## API Components

Implemented using Playwright API capabilities.

Responsibilities include:

* Service clients
* Request builders
* Contract management
* API interactions

API components provide a stable integration layer between automation and application services.

---

## Database Components

Implemented using SQL Server access.

Responsibilities include:

* Repositories
* Stored procedure execution
* Query execution
* Metadata validation
* Data validation

Database components support both data management and validation activities.

---

# Layer 5 – Technology Foundation

The Technology Foundation contains the underlying technologies used by the framework.

Current technologies include:

* Playwright
* FlaUI
* Microsoft SQL Server
* Playwright Test Runner

These technologies are consumed through framework components rather than directly by tests.

This ensures consistency and maintainability.

---

# Cross-Cutting Services

The following services support all framework layers.

---

## Validation Layer

The Validation Layer centralizes assertion and verification logic.

Examples:

* PartValidator
* VehicleValidator
* OutingValidator
* ProjectValidator
* AssemblyValidator

Validators may validate through:

* API responses
* Database queries
* UI state
* Desktop application state

Centralizing validation reduces duplication and ensures consistency across tests.

---

## Reporting & Observability

Reporting and Observability provide visibility into framework execution.

Current capabilities include:

* Playwright HTML Reports
* Screenshots
* Trace Files
* Execution Logs

These artifacts support:

* Failure analysis
* Debugging
* Auditability
* Test execution transparency

---

## Configuration & Infrastructure

Configuration and Infrastructure provide framework-wide services.

Examples:

* Environment configuration
* Global settings
* Jenkins integration
* Bitbucket integration
* Dependency Injection fixtures
* Utility libraries

This layer ensures consistent execution across environments.

---

# Future Evolution

The architecture intentionally prioritizes simplicity and maintainability.

Potential future enhancements include:

* Workflow Layer abstraction
* Advanced reporting and analytics
* Performance testing integration
* Business Object Factory patterns
* Distributed execution
* Test impact analysis
* AI-assisted automation capabilities

These enhancements will be introduced only when justified by business value and framework maturity.

---

# Summary

The Pratt Miller VES/STS Automation Framework is designed around business entities rather than application technologies.

By combining:

* Business Object-Centric Design
* Test Data Factory
* Data Seek Services
* Data Prerequisite Validation
* Unified Validation Layer
* Multi-Channel Execution Components

the framework provides a scalable and maintainable foundation for automation across Web, Desktop, API, and Database layers while supporting the complex business workflows inherent to the VES/STS ecosystem.
