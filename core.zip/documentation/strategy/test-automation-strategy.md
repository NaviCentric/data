# Pratt Miller VES2/STS Test Automation Strategy

## 1. Purpose

The purpose of this strategy is to establish a scalable, maintainable, and business-focused automation framework for the Pratt Miller VES2/STS ecosystem covering:

* Web Application Automation
* Desktop Application Automation
* Web API Automation
* Desktop API Automation
* Database Validation Automation

The strategy is designed to address the unique challenges of the VES2/STS ecosystem, where business workflows are highly dependent on complex data relationships spanning Projects, Vehicles, Assemblies, Parts, Outings, and supporting master data.

### Scope

The current scope of this strategy includes:

* Web Automation
* Desktop Automation
* API Automation
* Database Validation

Mobile automation is not applicable to the VES2/STS ecosystem as there is currently no mobile product within the application landscape and is therefore excluded from this strategy.

---

## 2. Automation Objectives

The automation program aims to:

* Accelerate regression testing cycles
* Improve release confidence
* Reduce manual testing effort
* Validate critical business workflows
* Detect data integrity issues early
* Support continuous integration and delivery initiatives
* Enable rapid impact assessment during releases
* Improve overall software quality through continuous validation

---

## 3. Technology Stack

| Layer               | Tool                                                           |
| ------------------- | -------------------------------------------------------------- |
| Web UI              | Playwright                                                     |
| Desktop UI          | FlaUI                                                          |
| Web APIs            | Playwright API Testing                                         |
| Desktop APIs        | Playwright API Testing                                         |
| Database Validation | SQL Server                                                     |
| Test Execution      | Playwright Test Runner                                         |
| Source Control      | Git                                                            |
| CI/CD               | Jenkins                                                        |
| Reporting           | Playwright HTML Reports (Current), Allure (Future Enhancement) |

### Database Validation

Database validation will be utilized to verify data integrity, environment consistency, and support validation activities across Category A and Category B automation scenarios.

This includes validation activities performed through database queries, metadata verification, and data-level assertions where appropriate.

### Tool Selection Rationale

Playwright was selected over Selenium for its built-in auto-wait capabilities, multi-browser support, and significantly lower flakiness in test execution. These capabilities improve reliability, reduce maintenance effort, and accelerate automation development.

FlaUI was selected for Windows desktop automation because it is currently the fastest and most capable open-source option available, offering better performance, stability, and maintainability compared to WinAppDriver.

### Reporting Strategy

During the initial framework implementation and PoC phases, Playwright’s native HTML reporting capabilities will be utilized for:

* Execution reporting
* Screenshots
* Trace files
* Failure diagnostics
* Debugging

Allure may be introduced as a future enhancement if advanced reporting, historical trend analysis, dashboarding, or enterprise reporting requirements emerge.

---

## 4. Automation Principles

### Principle 1: Automate at the Lowest Practical Layer

Whenever possible, validation should occur at the API and Database layers before considering UI automation.

**Priority Order**

```text
API Validation → Database Validation → UI Validation
```

This approach provides:

* Faster execution
* Improved stability
* Lower maintenance cost
* Better root-cause analysis

### Principle 2: UI Automation is Reserved for User Behavior Validation

UI automation will primarily focus on:

* User interactions
* Navigation
* Workflow execution
* Desktop-specific functionality
* Role-based access validation
* Screen-level validation

Business rule validation should primarily occur through APIs and Database checks.

### Principle 3: Data-Centric Automation

The primary challenge within VES2/STS is business data complexity rather than UI complexity.

Automation design decisions shall prioritize:

* Data availability
* Data relationships
* Data integrity
* Business workflow dependencies

### Principle 4: API-First Validation

API automation will serve as a primary validation layer within the automation framework whenever suitable interfaces are available.

API validations may include:

* Request and response validation
* Contract validation against Swagger/OpenAPI specifications
* Business rule validation
* Authorization and authentication validation
* Error handling validation
* Integration validation
* Data integrity verification

Where appropriate, APIs will be leveraged for test data seeding, workflow acceleration, and validation activities to reduce dependency on UI-based automation and improve execution efficiency.

---

## 5. Test Classification Strategy

The automation suite will be organized based on data ownership and dependency rather than technology layers.

### Category A | Automation-Owned Tests

#### Purpose

Validate individual features, business rules, and isolated functionality using data created and managed entirely by automation.

#### Characteristics

* Self-contained
* Creates its own data
* Cleans up after execution
* Independent execution
* Environment independent
* Suitable for CI/CD pipelines
* Suitable for parallel execution

#### Examples

* Part Creation
* Part History Validation
* User Table Management
* Attribute Management
* Configuration Management
* CRUD Operations
* Business Rule Validation

#### Benefits

* Highly reliable
* Repeatable
* Fast execution
* Minimal maintenance
* Suitable for continuous execution

### Category B | Environment-Owned Workflow Tests

#### Purpose

Validate critical business workflows using realistic business data available within production-refreshed environments.

#### Characteristics

* Executes against production-refreshed environments
* Utilizes existing business entities
* Validates realistic business workflows
* Focuses on business process coverage
* Leverages existing business relationships

#### Examples

* Create Outing Group on existing vehicle assembly
* Create Outing on existing outing group
* Create Outing Working on existing outing
* Vehicle Assembly Workflow
* Project-Level Business Processes

#### Rationale

Many workflows depend on extensive prerequisite business relationships:

```text
Project → Outing Group → Outing → Vehicle → Assembly Attributes → Parts → Part Attributes
```

Creating these relationships dynamically for every test introduces significant maintenance overhead and execution complexity. Therefore, workflow validation will leverage production-representative datasets already available in the environment.
## 6. Test Data Management

For Category A (Automation-Owned) tests, the framework will implement an Adapter Pattern for test data creation.

This allows test data to be provisioned through any available layer: UI, API, or Database depending on what information and access is available at the time of execution.

### Examples

#### API-Based Creation

If an API endpoint exists to create a Part, the adapter will create the data using APIs.

#### Database-Based Creation

If only database access is available, the adapter will seed data directly through SQL.

#### UI-Based Creation

If UI is the only available mechanism, the adapter will drive the application UI to create the required data.

### Benefits

* Flexibility to switch data creation mechanisms without changing test logic
* Resilience when specific layers are unavailable
* Consistency in test data setup
* Reduced framework maintenance
* Improved reusability

### Category A Data Lifecycle

```text
Create Data
→ Execute Test
→ Validate Results
→ Cleanup Data
```

This ensures complete independence, repeatability, and environment portability.

### Category B Data Management

Category B workflow tests leverage production-representative datasets available within the environment.

These datasets are:

* Discovered dynamically through the Data Seek Layer
* Validated through the Data Prerequisite Validation Layer
* Never hardcoded within automation scripts

This approach minimizes maintenance while ensuring realistic workflow coverage.

---

## 7. Environment Strategy

### Category A – Automation-Owned Tests

Category A tests are environment-independent and can execute in:

* Test
* Integration
* UAT

Since these tests create and manage their own data, they do not rely on pre-existing business datasets.

### Category B – Environment-Owned Workflow Tests

Category B tests require production-representative business data and therefore depend on environments that receive periodic production refreshes.

These tests will primarily execute against:

* Test

where realistic business relationships exist across Projects, Outings, Vehicles, Assemblies, and Parts.

---

## 8. Data Seek Strategy

Category B tests shall utilize a Data Seek Layer to identify suitable records at runtime.

### Objective

Avoid:

* Hardcoded IDs
* Environment-specific references
* Brittle automation

### Not Recommended

```text
outingId = 12345
partId = 56789
```

### Recommended

```text
Find Project
Find Eligible Outing Group
Find Eligible Outing
Find Vehicle
Find Assembly Attributes
Find Parts
```

### Data Seek Sources

Data seek may utilize:

* Database Queries
* API Searches
* Business Filters

### Examples

* Active Projects
* Active Outing Groups
* Active Outings
* Vehicles linked to Outings
* Assemblies with valid attributes
* Parts associated with assemblies

### Benefits

* Survives production refreshes
* Survives environment resets
* Reduces maintenance
* Improves reliability

### Missing Data Handling

If the Data Seek Layer does not find expected data patterns for a given scenario, the test will be skipped with a clear diagnostic message.

This is an intentional design decision.

If the required data does not exist within a production-refreshed environment, it may indicate that the workflow is not currently active or relevant within the production ecosystem.

Skipping the scenario while reporting the missing prerequisite provides better visibility and prevents false failures.

---

## 9. Data Prerequisite Validation Strategy

Before executing Category B workflow tests, prerequisite validation shall be performed.

### Objective

Prevent false failures caused by missing or invalid environment data.

### Examples

Validate:

* Active Projects exist
* Active Outing Groups exist
* Active Outings exist
* Vehicles exist for selected Outings
* Assembly Attributes exist
* Parts exist
* Required Master Data exists

### Outcome

If prerequisites are not met:

* Tests are skipped
* Environment issue is reported
* False failures are avoided

This process serves as Environment Certification prior to workflow execution.

---

## 10. Business Object Model

To improve maintainability and reduce duplication across automation layers, the framework will implement a Business Object Model.

Core business entities such as:

* Project
* Outing Group
* Outing
* Vehicle
* Assembly Attributes
* Part
* Part Attributes

will be represented as reusable domain objects within the framework.

### Example

A Part object may contain:

* Part ID
* Part Type ID
* Area
* Status
* Assembly References

The same object can be consumed by:

* UI Layer
* API Layer
* Database Layer
* Data Seek Layer
* Data Factory Layer

### Benefits

* Consistent business representation across all layers
* Reduced duplication of mapping logic
* Easier maintenance when data structures evolve
* Improved readability of automation code
* Better alignment with business terminology

Automation scripts will operate on business concepts rather than technical implementation details.

## 11. Automation Architecture

The automation framework follows a Business Object-Centric Architecture designed to support Web, Desktop, API, and Database automation through a unified automation platform.

The framework is organized around business entities rather than application technologies, enabling consistent automation patterns across all supported layers.

Key architectural concepts include:

* Data Management through Test Data Factory, Data Seek, and Data Prerequisite Validation services
* Business Object Model representing core VES2/STS entities
* Reusable execution components across Web, Desktop, API, and Database layers
* Centralized validation services
* Shared reporting, observability, and configuration capabilities

The architecture is designed to support both Category A (Automation-Owned) and Category B (Environment-Owned) automation strategies while maintaining separation between business logic and implementation details.

Refer to the Automation Framework Architecture documentation and architecture diagrams for implementation details.

---

## 12. Execution Strategy

The automation suite will be executed after each deployment to the target environment.

### Scope

Execution will include:

* Category A (Automation-Owned) tests
* Category B (Environment-Owned Workflow) tests
* API validations
* Database validations
* Data prerequisite checks

The exact test scope may be adjusted based on release timelines, business priorities, and environment readiness.

As the automation program matures, additional execution models such as smoke testing, nightly regression, and CI/CD-triggered execution may be introduced.

---

## 13. Strategic Outcome

The Pratt Miller VES2/STS automation framework will follow a hybrid model consisting of:

1. **Automation-Owned Tests (Category A)** for independent and repeatable validation.

2. **Environment-Owned Workflow Tests (Category B)** for realistic business workflow validation using production-representative datasets.

3. **Data Seek and Data Prerequisite Validation layers** to ensure long-term stability and maintainability.

4. **A Business Object Model** to provide a consistent representation of business entities across UI, API, Database, and Data Management layers.

5. **An Adapter-based Data Factory** that enables flexible test data creation through UI, API, or Database mechanisms.

This strategy balances automation reliability, execution speed, business coverage, and maintenance effort while addressing the complex data dependencies inherent to the VES2/STS platform.

By combining environment-independent validation with production-representative workflow testing, the framework provides rapid feedback for development teams while maintaining high confidence in business-critical functionality across releases.

