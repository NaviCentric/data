/**
 * Database Component Index
 * Exports all database components, repositories, queries, and procedures
 */

// Base repository (connection pool + raw query execution)
export { DatabaseRepository } from './DatabaseRepository.js';

// Entity repositories
export { ProjectRepository } from './repositories/ProjectRepository.js';
export { OutingGroupRepository, OutingRepository } from './repositories/OutingRepository.js';
export { VehicleRepository } from './repositories/VehicleRepository.js';
export {
  AssemblyRepository,
  PartRepository,
  PartAttributeRepository,
  AssemblyAttributeRepository,
} from './repositories/PartRepository.js';

// Query definitions
export { ProjectQueries } from './queries/ProjectQueries.js';
export { OutingGroupQueries, OutingQueries } from './queries/OutingQueries.js';
export { VehicleQueries } from './queries/VehicleQueries.js';
export { AssemblyQueries, PartQueries, PartAttributeQueries, AssemblyAttributeQueries } from './queries/PartQueries.js';

// Stored procedure definitions
export { StoredProcedures } from './procedures/StoredProcedures.js';


/**
 * Specific repositories will be exported from here
 * Example:
 * export { ProjectRepository } from './repositories/ProjectRepository.js';
 * export { PartRepository } from './repositories/PartRepository.js';
 */
