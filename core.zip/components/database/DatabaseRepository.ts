/**
 * Database Repository — Base
 * Manages the mssql connection pool and provides low-level
 * query and stored procedure execution for all entity repositories.
 */

import * as sql from 'mssql';
import { logger } from '../../core/logger/index.js';
import { config } from '../../core/config/index.js';

const poolConfig: sql.config = {
  server: config.database.host,
  port: config.database.port,
  user: config.database.user,
  password: config.database.password,
  database: config.database.database,
  requestTimeout: config.database.timeout,
  options: {
    encrypt: false,
    trustServerCertificate: true,
  },
};

let pool: sql.ConnectionPool | null = null;

async function getPool(): Promise<sql.ConnectionPool> {
  if (!pool || !pool.connected) {
    pool = await new sql.ConnectionPool(poolConfig).connect();
    logger.info(
      `Database connected: ${config.database.host}:${config.database.port}/${config.database.database}`
    );
  }
  return pool;
}

export class DatabaseRepository {
  /**
   * Execute a raw parameterized T-SQL query.
   * @param query  - SQL string with @param placeholders
   * @param params - key/value pairs mapped to @param names
   */
  async executeQuery<T>(
    query: string,
    params: Record<string, unknown> = {}
  ): Promise<T[]> {
    logger.info(`Executing query with params: ${JSON.stringify(Object.keys(params))}`);
    const connection = await getPool();
    const request = connection.request();

    for (const [key, value] of Object.entries(params)) {
      request.input(key, value);
    }

    const result = await request.query<T>(query);
    return result.recordset;
  }

  /**
   * Execute a stored procedure by name.
   * @param procedureName - SQL Server procedure name
   * @param params        - key/value pairs mapped to procedure parameters
   */
  async executeStoredProcedure<T>(
    procedureName: string,
    params: Record<string, unknown> = {}
  ): Promise<T[]> {
    logger.info(`Executing stored procedure: ${procedureName}`);
    const connection = await getPool();
    const request = connection.request();

    for (const [key, value] of Object.entries(params)) {
      request.input(key, value);
    }

    const result = await request.execute<T>(procedureName);
    return result.recordset;
  }

  /**
   * Validate the database connection is reachable.
   */
  async validateConnection(): Promise<boolean> {
    try {
      await getPool();
      return true;
    } catch (err) {
      logger.error(`Database connection failed: ${String(err)}`);
      return false;
    }
  }

  /**
   * Close the connection pool.
   */
  async closeConnection(): Promise<void> {
    if (pool && pool.connected) {
      await pool.close();
      pool = null;
      logger.info('Database connection closed');
    }
  }
}

export default DatabaseRepository;

