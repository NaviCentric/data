/**
 * Part Repository
 * Data access for Assembly, Part, and Attribute business objects
 */

import { DatabaseRepository } from '../DatabaseRepository.js';
import {
  AssemblyQueries,
  PartQueries,
  PartAttributeQueries,
  AssemblyAttributeQueries,
} from '../queries/PartQueries.js';
import type {
  Assembly,
  Part,
  PartAttribute,
  AssemblyAttribute,
} from '../../../domain/models/index.js';

export class AssemblyRepository extends DatabaseRepository {
  async findByVehicle(vehicleId: string): Promise<Assembly[]> {
    return this.executeQuery<Assembly>(AssemblyQueries.findByVehicleId, {
      vehicleId,
      status: 'Active',
    });
  }

  async exists(id: string): Promise<boolean> {
    const rows = await this.executeQuery<{ count: number }>(
      AssemblyQueries.existsById,
      { id }
    );
    return (rows[0]?.count ?? 0) > 0;
  }
}

export class PartRepository extends DatabaseRepository {
  async findByAssembly(assemblyId: string): Promise<Part[]> {
    return this.executeQuery<Part>(PartQueries.findByAssemblyId, {
      assemblyId,
      status: 'Active',
    });
  }

  async findById(id: string): Promise<Part | null> {
    const rows = await this.executeQuery<Part>(PartQueries.findById, { id });
    return rows[0] ?? null;
  }

  async exists(id: string): Promise<boolean> {
    const rows = await this.executeQuery<{ count: number }>(
      PartQueries.existsById,
      { id }
    );
    return (rows[0]?.count ?? 0) > 0;
  }
}

export class PartAttributeRepository extends DatabaseRepository {
  async findByPart(partId: string): Promise<PartAttribute[]> {
    return this.executeQuery<PartAttribute>(PartAttributeQueries.findByPartId, {
      partId,
    });
  }
}

export class AssemblyAttributeRepository extends DatabaseRepository {
  async findByAssembly(assemblyId: string): Promise<AssemblyAttribute[]> {
    return this.executeQuery<AssemblyAttribute>(
      AssemblyAttributeQueries.findByAssemblyId,
      { assemblyId }
    );
  }
}

export default PartRepository;
