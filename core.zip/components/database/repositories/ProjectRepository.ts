/**
 * Project Repository
 * Data access for Project business objects
 */

import { DatabaseRepository } from '../DatabaseRepository.js';
import { ProjectQueries } from '../queries/ProjectQueries.js';
import type { Project } from '../../../domain/models/index.js';

export class ProjectRepository extends DatabaseRepository {
  async findActive(): Promise<Project[]> {
    return this.executeQuery<Project>(ProjectQueries.findAll, {
      status: 'Active',
    });
  }

  async findById(id: string): Promise<Project | null> {
    const rows = await this.executeQuery<Project>(ProjectQueries.findById, { id });
    return rows[0] ?? null;
  }

  async exists(id: string): Promise<boolean> {
    const rows = await this.executeQuery<{ count: number }>(
      ProjectQueries.existsById,
      { id }
    );
    return (rows[0]?.count ?? 0) > 0;
  }
}

export default ProjectRepository;
