/**
 * Outing Repository
 * Data access for OutingGroup and Outing business objects
 */

import { DatabaseRepository } from '../DatabaseRepository.js';
import { OutingGroupQueries, OutingQueries } from '../queries/OutingQueries.js';
import type { OutingGroup, Outing } from '../../../domain/models/index.js';

export class OutingGroupRepository extends DatabaseRepository {
  async findByProject(projectId: string): Promise<OutingGroup[]> {
    return this.executeQuery<OutingGroup>(OutingGroupQueries.findByProjectId, {
      projectId,
      status: 'Active',
    });
  }
}

export class OutingRepository extends DatabaseRepository {
  async findByOutingGroup(outingGroupId: string): Promise<Outing[]> {
    return this.executeQuery<Outing>(OutingQueries.findByOutingGroupId, {
      outingGroupId,
      status: 'Active',
    });
  }

  async findById(id: string): Promise<Outing | null> {
    const rows = await this.executeQuery<Outing>(OutingQueries.findById, { id });
    return rows[0] ?? null;
  }

  async exists(id: string): Promise<boolean> {
    const rows = await this.executeQuery<{ count: number }>(
      OutingQueries.existsById,
      { id }
    );
    return (rows[0]?.count ?? 0) > 0;
  }
}

export default OutingRepository;
