/**
 * Vehicle Repository
 * Data access for Vehicle business objects
 */

import { DatabaseRepository } from '../DatabaseRepository.js';
import { VehicleQueries } from '../queries/VehicleQueries.js';
import type { Vehicle } from '../../../domain/models/index.js';

export class VehicleRepository extends DatabaseRepository {
  async findByOuting(outingId: string): Promise<Vehicle[]> {
    return this.executeQuery<Vehicle>(VehicleQueries.findByOutingId, {
      outingId,
      status: 'Active',
    });
  }

  async findById(id: string): Promise<Vehicle | null> {
    const rows = await this.executeQuery<Vehicle>(VehicleQueries.findById, { id });
    return rows[0] ?? null;
  }

  async exists(id: string): Promise<boolean> {
    const rows = await this.executeQuery<{ count: number }>(
      VehicleQueries.existsById,
      { id }
    );
    return (rows[0]?.count ?? 0) > 0;
  }
}

export default VehicleRepository;
