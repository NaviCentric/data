/**
 * Stored Procedure Wrappers
 *
 * Encapsulates execution of SQL Server stored procedures.
 * Each wrapper maps procedure parameters to typed inputs and
 * returns typed Business Objects or scalar results.
 *
 * Stored procedure wrappers are consumed by Repositories and
 * the Data Management layer.
 *
 * Examples (Phase 2+):
 *   GetOutingsByProjectProcedure     - Wraps usp_GetOutingsByProject
 *   GetVehicleAssemblyProcedure      - Wraps usp_GetVehicleAssembly
 *   CreatePartProcedure              - Wraps usp_CreatePart
 *   ValidateEnvironmentProcedure     - Wraps usp_ValidateEnvironment
 */
