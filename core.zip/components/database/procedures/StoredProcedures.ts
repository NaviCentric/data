/**
 * Stored Procedure Wrappers
 * Typed wrappers for SQL Server stored procedures used in VES/STS
 *
 * Each entry defines:
 *   - name   : the procedure name as it exists in SQL Server
 *   - params : the parameter names expected by that procedure
 */

export const StoredProcedures = {
  getOutingsByProject: {
    name: 'usp_GetOutingsByProject',
    params: {
      projectId: '@ProjectId',
      status: '@Status',
    },
  },

  getVehiclesByOuting: {
    name: 'usp_GetVehiclesByOuting',
    params: {
      outingId: '@OutingId',
    },
  },

  getAssembliesByVehicle: {
    name: 'usp_GetAssembliesByVehicle',
    params: {
      vehicleId: '@VehicleId',
    },
  },

  createPart: {
    name: 'usp_CreatePart',
    params: {
      assemblyId: '@AssemblyId',
      name: '@Name',
      partNumber: '@PartNumber',
      description: '@Description',
      status: '@Status',
    },
  },

  deletePart: {
    name: 'usp_DeletePart',
    params: {
      partId: '@PartId',
    },
  },

  validateEnvironment: {
    name: 'usp_ValidateEnvironment',
    params: {},
  },
} as const;
