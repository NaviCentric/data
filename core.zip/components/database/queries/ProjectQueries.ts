/**
 * Project SQL Queries
 * Parameterized T-SQL queries for Project data operations
 */

export const ProjectQueries = {
  findAll: `
    SELECT
      p.ProjectId   AS id,
      p.Name        AS name,
      p.Description AS description,
      p.Status      AS status,
      p.CreatedAt   AS createdAt,
      p.UpdatedAt   AS updatedAt
    FROM Projects p
    WHERE p.Status = @status
    ORDER BY p.Name
  `,

  findById: `
    SELECT
      p.ProjectId   AS id,
      p.Name        AS name,
      p.Description AS description,
      p.Status      AS status,
      p.CreatedAt   AS createdAt,
      p.UpdatedAt   AS updatedAt
    FROM Projects p
    WHERE p.ProjectId = @id
  `,

  existsById: `
    SELECT COUNT(1) AS count
    FROM Projects
    WHERE ProjectId = @id
  `,
} as const;
