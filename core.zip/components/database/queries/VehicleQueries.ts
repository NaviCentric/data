/**
 * Vehicle SQL Queries
 * Parameterized T-SQL queries for Vehicle data operations
 */

export const VehicleQueries = {
  findByOutingId: `
    SELECT
      v.VehicleId AS id,
      v.OutingId  AS outingId,
      v.VIN       AS vin,
      v.Make      AS make,
      v.Model     AS model,
      v.Year      AS year,
      v.Status    AS status
    FROM Vehicles v
    WHERE v.OutingId = @outingId
      AND v.Status = @status
    ORDER BY v.VIN
  `,

  findById: `
    SELECT
      v.VehicleId AS id,
      v.OutingId  AS outingId,
      v.VIN       AS vin,
      v.Make      AS make,
      v.Model     AS model,
      v.Year      AS year,
      v.Status    AS status
    FROM Vehicles v
    WHERE v.VehicleId = @id
  `,

  existsById: `
    SELECT COUNT(1) AS count
    FROM Vehicles
    WHERE VehicleId = @id
  `,
} as const;
