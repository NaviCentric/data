/**
 * SQL Query Definitions
 *
 * Contains parameterized T-SQL query strings used by Repositories.
 * Centralizing queries here avoids duplication, improves readability,
 * and makes queries easy to review and maintain independently of
 * repository logic.
 *
 * Queries support:
 *   - Data Seek Service (finding runtime data for Category B tests)
 *   - Data Prerequisite Validation (environment certification)
 *   - Database-level assertions and metadata validation
 *
 * Examples (Phase 2+):
 *   ProjectQueries             - SELECT queries for Projects
 *   OutingQueries              - SELECT queries for Outings
 *   VehicleQueries             - SELECT queries for Vehicles
 *   AssemblyQueries            - SELECT queries for Assemblies
 *   PartQueries                - SELECT queries for Parts
 */
