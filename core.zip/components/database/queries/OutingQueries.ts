/**
 * Outing SQL Queries
 * Parameterized T-SQL queries for Outing and OutingGroup data operations
 */

export const OutingGroupQueries = {
  findByProjectId: `
    SELECT
      og.OutingGroupId AS id,
      og.ProjectId     AS projectId,
      og.Name          AS name,
      og.Description   AS description,
      og.Status        AS status
    FROM OutingGroups og
    WHERE og.ProjectId = @projectId
      AND og.Status = @status
    ORDER BY og.Name
  `,
} as const;

export const OutingQueries = {
  findByOutingGroupId: `
    SELECT
      o.OutingId      AS id,
      o.OutingGroupId AS outingGroupId,
      o.Name          AS name,
      o.Description   AS description,
      o.StartDate     AS startDate,
      o.EndDate       AS endDate,
      o.Status        AS status
    FROM Outings o
    WHERE o.OutingGroupId = @outingGroupId
      AND o.Status = @status
    ORDER BY o.StartDate DESC
  `,

  findById: `
    SELECT
      o.OutingId      AS id,
      o.OutingGroupId AS outingGroupId,
      o.Name          AS name,
      o.Description   AS description,
      o.StartDate     AS startDate,
      o.EndDate       AS endDate,
      o.Status        AS status
    FROM Outings o
    WHERE o.OutingId = @id
  `,

  existsById: `
    SELECT COUNT(1) AS count
    FROM Outings
    WHERE OutingId = @id
  `,
} as const;
