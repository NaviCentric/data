/**
 * Part SQL Queries
 * Parameterized T-SQL queries for Assembly, Part, and Attribute operations
 */

export const AssemblyQueries = {
  findByVehicleId: `
    SELECT
      a.AssemblyId  AS id,
      a.VehicleId   AS vehicleId,
      a.Name        AS name,
      a.Description AS description,
      a.Status      AS status
    FROM Assemblies a
    WHERE a.VehicleId = @vehicleId
      AND a.Status = @status
    ORDER BY a.Name
  `,

  existsById: `
    SELECT COUNT(1) AS count
    FROM Assemblies
    WHERE AssemblyId = @id
  `,
} as const;

export const PartQueries = {
  findByAssemblyId: `
    SELECT
      p.PartId      AS id,
      p.AssemblyId  AS assemblyId,
      p.Name        AS name,
      p.PartNumber  AS partNumber,
      p.Description AS description,
      p.Status      AS status
    FROM Parts p
    WHERE p.AssemblyId = @assemblyId
      AND p.Status = @status
    ORDER BY p.PartNumber
  `,

  findById: `
    SELECT
      p.PartId      AS id,
      p.AssemblyId  AS assemblyId,
      p.Name        AS name,
      p.PartNumber  AS partNumber,
      p.Description AS description,
      p.Status      AS status
    FROM Parts p
    WHERE p.PartId = @id
  `,

  existsById: `
    SELECT COUNT(1) AS count
    FROM Parts
    WHERE PartId = @id
  `,
} as const;

export const PartAttributeQueries = {
  findByPartId: `
    SELECT
      pa.PartAttributeId AS id,
      pa.PartId          AS partId,
      pa.AttributeName   AS attributeName,
      pa.AttributeValue  AS attributeValue
    FROM PartAttributes pa
    WHERE pa.PartId = @partId
  `,
} as const;

export const AssemblyAttributeQueries = {
  findByAssemblyId: `
    SELECT
      aa.AssemblyAttributeId AS id,
      aa.AssemblyId          AS assemblyId,
      aa.AttributeName       AS attributeName,
      aa.AttributeValue      AS attributeValue
    FROM AssemblyAttributes aa
    WHERE aa.AssemblyId = @assemblyId
  `,
} as const;
