/**
 * VES2 Web Component Index
 */

export { WebUIComponent } from './WebUIComponent.js';
export * from './pages/index.js';
export * from './fragments/index.js';
