/**
 * Web UI Execution Component — VES2
 * Layer 4: Web UI Components using Playwright
 *
 * Responsibilities:
 * - Page navigation
 * - UI interactions
 * - Browser-based validation
 * - Page object management
 */

import { Page } from '@playwright/test';
import { logger } from '../../../core/logger/index.js';

export class WebUIComponent {
  constructor(protected page: Page) {
    this.logger.info('Initializing component: WebUI (VES2)');
  }

  protected logger = logger;

  async navigateTo(url: string): Promise<void> {
    this.logger.info(`Navigating to: ${url}`);
    await this.page.goto(url);
  }

  getPage(): Page {
    return this.page;
  }
}
