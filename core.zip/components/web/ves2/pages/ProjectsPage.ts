/**
 * Projects Page — VES2
 * Reference: LoginPage.ts + BasePage.ts
 */

import { Page } from '@playwright/test';
import { BasePage } from './BasePage.js';
import { WijmoGridFragment } from '../fragments/WijmoGridFragment.js';

export class ProjectsPage extends BasePage {
  readonly grid: WijmoGridFragment;

  constructor(page: Page) {
    super(page, '/projects');
    this.grid = new WijmoGridFragment(page, '[data-grid="projects"]');
  }

  async selectProject(projectName: string): Promise<void> {
    // TODO
    void projectName;
  }

  async getProjectCount(): Promise<number> {
    // TODO
    return 0;
  }
}
