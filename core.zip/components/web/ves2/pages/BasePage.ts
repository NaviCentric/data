/**
 * Base Page — VES2
 *
 * All VES2 Page Objects extend BasePage.
 * Provides shared navigation, header interactions, and wait utilities.
 *
 * Usage:
 *   class ProjectsPage extends BasePage {
 *     constructor(page: Page) { super(page, '/projects'); }
 *   }
 */

import { Page } from '@playwright/test';
import { config } from '../../../../core/config/index.js';

export abstract class BasePage {
  constructor(protected page: Page, protected path: string) {}

  async navigate(): Promise<void> {
    // TODO: goto config.baseUrl + this.path
    // TODO: wait for page to reach 'networkidle' or specific element
    void config;
  }

  async getTitle(): Promise<string> {
    // TODO: return page.title()
    return '';
  }

  async waitForLoad(): Promise<void> {
    // TODO: wait for loading indicator to disappear
    // TODO: wait for main content container to be visible
  }

  async screenshot(name: string): Promise<void> {
    // TODO: page.screenshot({ path: `screenshots/${name}.png` })
    void name;
  }
}
