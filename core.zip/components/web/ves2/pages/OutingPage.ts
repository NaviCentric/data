/**
 * Outing Page — VES2
 * Reference: LoginPage.ts + BasePage.ts
 */

import { Page } from '@playwright/test';
import { BasePage } from './BasePage.js';
import { WijmoGridFragment } from '../fragments/WijmoGridFragment.js';

export class OutingPage extends BasePage {
  readonly grid: WijmoGridFragment;

  constructor(page: Page) {
    super(page, '/outings');
    this.grid = new WijmoGridFragment(page, '[data-grid="outings"]');
  }

  async createOuting(name: string): Promise<void> {
    // TODO
    void name;
  }

  async selectOuting(outingName: string): Promise<void> {
    // TODO
    void outingName;
  }
}
