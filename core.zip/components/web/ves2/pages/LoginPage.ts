/**
 * Login Page — VES2
 *
 * Handles authentication for the VES2 web application.
 *
 * Usage:
 *   const login = new LoginPage(page);
 *   await login.navigate();
 *   await login.loginAs('username', 'password');
 */

import { Page } from '@playwright/test';
import { BasePage } from './BasePage.js';

export class LoginPage extends BasePage {
  constructor(page: Page) {
    super(page, '/login');
  }

  async loginAs(username: string, password: string): Promise<void> {
    // TODO: fill username input
    // TODO: fill password input
    // TODO: click login button
    // TODO: wait for redirect to dashboard
    void username; void password;
  }

  async getErrorMessage(): Promise<string> {
    // TODO: return text of error message element
    return '';
  }

  async isLoggedIn(): Promise<boolean> {
    // TODO: check for presence of authenticated user element
    return false;
  }
}
