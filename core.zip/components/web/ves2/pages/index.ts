/**
 * VES2 Web Pages Index
 */

export { BasePage } from './BasePage.js';
export { LoginPage } from './LoginPage.js';
export { ProjectsPage } from './ProjectsPage.js';
export { OutingPage } from './OutingPage.js';
