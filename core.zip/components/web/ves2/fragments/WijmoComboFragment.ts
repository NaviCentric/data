/**
 * Wijmo ComboBox Fragment — VES2
 * Reference: WijmoGridFragment.ts
 */

import { Page, Locator } from '@playwright/test';

export class WijmoComboFragment {
  private combo: Locator;

  constructor(private page: Page, private selector: string) {
    this.combo = page.locator(selector);
  }

  async selectByText(text: string): Promise<void> {
    // TODO
    void text;
  }

  async selectByValue(value: string): Promise<void> {
    // TODO
    void value;
  }

  async getSelectedText(): Promise<string> {
    // TODO
    return '';
  }

  async getOptions(): Promise<string[]> {
    // TODO
    return [];
  }
}
