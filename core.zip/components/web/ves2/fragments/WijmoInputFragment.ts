/**
 * Wijmo Input Fragment — VES2
 * Reference: WijmoGridFragment.ts
 */

import { Page, Locator } from '@playwright/test';

export class WijmoInputFragment {
  private input: Locator;

  constructor(private page: Page, private selector: string) {
    this.input = page.locator(selector);
  }

  async setValue(value: string): Promise<void> {
    // TODO
    void value;
  }

  async getValue(): Promise<string> {
    // TODO
    return '';
  }

  async clear(): Promise<void> {
    // TODO
  }
}
