/**
 * Web UI Component Index
 * Exports per-application web namespaces: ves2
 */

export * as ves2 from './ves2/index.js';
