/**
 * STS Workflow Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type {
  WorkflowResponse,
  WorkflowActivityResponse,
  CreateWorkflowRequest,
  AddWorkflowActivityRequest,
  ApiListResponse,
} from '../contracts/ApiContracts.js';
import type { Workflow, WorkflowActivity } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class WorkflowClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/workflows`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }

  async getAll(): Promise<Workflow[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<WorkflowResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Workflow> {
    const data = await this.get(`${this.baseUrl}/${id}`) as WorkflowResponse;
    return this.toModel(data);
  }

  async create(request: CreateWorkflowRequest): Promise<Workflow> {
    const data = await this.post(this.baseUrl, request) as WorkflowResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  async getActivities(workflowId: string): Promise<WorkflowActivity[]> {
    const data = await this.get(`${this.baseUrl}/${workflowId}/activities`) as ApiListResponse<WorkflowActivityResponse>;
    return data.items.map(this.toActivityModel);
  }

  async addActivity(request: AddWorkflowActivityRequest): Promise<WorkflowActivity> {
    const data = await this.post(
      `${this.baseUrl}/${request.workflowId}/activities`,
      request
    ) as WorkflowActivityResponse;
    return this.toActivityModel(data);
  }

  private toModel(response: WorkflowResponse): Workflow {
    return {
      id: response.workflowId,
      name: response.name,
      description: response.description,
      version: response.version,
      status: response.status as Workflow['status'],
      createdAt: new Date(response.createdAt),
      updatedAt: new Date(response.updatedAt),
    };
  }

  private toActivityModel(response: WorkflowActivityResponse): WorkflowActivity {
    return {
      id: response.workflowActivityId,
      workflowId: response.workflowId,
      activityId: response.activityId,
      stepOrder: response.stepOrder,
    };
  }
}
