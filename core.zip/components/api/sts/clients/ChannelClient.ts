/**
 * STS Channel Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type { ChannelResponse, CreateChannelRequest, ApiListResponse } from '../contracts/ApiContracts.js';
import type { Channel } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class ChannelClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/channels`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }

  async getAll(): Promise<Channel[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<ChannelResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Channel> {
    const data = await this.get(`${this.baseUrl}/${id}`) as ChannelResponse;
    return this.toModel(data);
  }

  async create(request: CreateChannelRequest): Promise<Channel> {
    const data = await this.post(this.baseUrl, request) as ChannelResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  private toModel(response: ChannelResponse): Channel {
    return {
      id: response.channelId,
      name: response.name,
      description: response.description,
      channelType: response.channelType,
      status: response.status as Channel['status'],
      createdAt: new Date(response.createdAt),
      updatedAt: new Date(response.updatedAt),
    };
  }
}
