/**
 * STS Activity Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type { ActivityResponse, CreateActivityRequest, ApiListResponse } from '../contracts/ApiContracts.js';
import type { Activity } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class ActivityClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/activities`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }

  async getAll(): Promise<Activity[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<ActivityResponse>;
    return data.items.map(this.toModel);
  }

  async getByChannel(channelId: string): Promise<Activity[]> {
    const data = await this.get(`${this.baseUrl}?channelId=${channelId}`) as ApiListResponse<ActivityResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Activity> {
    const data = await this.get(`${this.baseUrl}/${id}`) as ActivityResponse;
    return this.toModel(data);
  }

  async create(request: CreateActivityRequest): Promise<Activity> {
    const data = await this.post(this.baseUrl, request) as ActivityResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  private toModel(response: ActivityResponse): Activity {
    return {
      id: response.activityId,
      channelId: response.channelId,
      name: response.name,
      description: response.description,
      activityType: response.activityType,
      sequenceOrder: response.sequenceOrder,
      status: response.status as Activity['status'],
      createdAt: new Date(response.createdAt),
      updatedAt: new Date(response.updatedAt),
    };
  }
}
