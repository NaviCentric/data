/**
 * STS API Contracts
 * TypeScript interfaces representing the STS2 API wire format (request/response shapes).
 * Derived from STS2 Swagger/OpenAPI specifications.
 *
 * Entities: Channel, Activity, Workflow
 */

// ─────────────────────────────────────────────────────────────────────────────
// Shared
// ─────────────────────────────────────────────────────────────────────────────

export interface ApiErrorContract {
  statusCode: number;
  message: string;
  errors?: string[];
}

export interface ApiListResponse<T> {
  items: T[];
  totalCount: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Channel
// ─────────────────────────────────────────────────────────────────────────────

export interface ChannelResponse {
  channelId: string;
  name: string;
  description?: string;
  channelType: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateChannelRequest {
  name: string;
  description?: string;
  channelType: string;
  status?: string;
}

export interface UpdateChannelRequest {
  name?: string;
  description?: string;
  channelType?: string;
  status?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Activity
// ─────────────────────────────────────────────────────────────────────────────

export interface ActivityResponse {
  activityId: string;
  channelId: string;
  name: string;
  description?: string;
  activityType: string;
  sequenceOrder: number;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateActivityRequest {
  channelId: string;
  name: string;
  description?: string;
  activityType: string;
  sequenceOrder?: number;
}

export interface UpdateActivityRequest {
  name?: string;
  description?: string;
  activityType?: string;
  sequenceOrder?: number;
  status?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Workflow
// ─────────────────────────────────────────────────────────────────────────────

export interface WorkflowResponse {
  workflowId: string;
  name: string;
  description?: string;
  version: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface WorkflowActivityResponse {
  workflowActivityId: string;
  workflowId: string;
  activityId: string;
  stepOrder: number;
}

export interface CreateWorkflowRequest {
  name: string;
  description?: string;
  version?: string;
}

export interface UpdateWorkflowRequest {
  name?: string;
  description?: string;
  version?: string;
  status?: string;
}

export interface AddWorkflowActivityRequest {
  workflowId: string;
  activityId: string;
  stepOrder: number;
}
