/**
 * STS Request Builders
 * Fluent builders for constructing well-formed STS2 API request payloads.
 * Entities: Channel, Activity, Workflow
 */

import type {
  CreateChannelRequest,
  CreateActivityRequest,
  CreateWorkflowRequest,
  AddWorkflowActivityRequest,
} from '../contracts/ApiContracts.js';
import type { Channel, Activity, Workflow } from '../../../../domain/models/index.js';

// ─────────────────────────────────────────────────────────────────────────────
// Channel Builder
// ─────────────────────────────────────────────────────────────────────────────

export class ChannelRequestBuilder {
  private request: Partial<CreateChannelRequest> = {};

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  withChannelType(channelType: string): this {
    this.request.channelType = channelType;
    return this;
  }

  fromDomainModel(channel: Channel): this {
    this.request.name = channel.name;
    this.request.description = channel.description;
    this.request.channelType = channel.channelType;
    this.request.status = channel.status;
    return this;
  }

  build(): CreateChannelRequest {
    if (!this.request.name) throw new Error('ChannelRequest: name is required');
    if (!this.request.channelType) throw new Error('ChannelRequest: channelType is required');
    return this.request as CreateChannelRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Activity Builder
// ─────────────────────────────────────────────────────────────────────────────

export class ActivityRequestBuilder {
  private request: Partial<CreateActivityRequest> = {};

  withChannelId(channelId: string): this {
    this.request.channelId = channelId;
    return this;
  }

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  withActivityType(activityType: string): this {
    this.request.activityType = activityType;
    return this;
  }

  withSequenceOrder(order: number): this {
    this.request.sequenceOrder = order;
    return this;
  }

  fromDomainModel(activity: Activity): this {
    this.request.channelId = activity.channelId;
    this.request.name = activity.name;
    this.request.description = activity.description;
    this.request.activityType = activity.activityType;
    this.request.sequenceOrder = activity.sequenceOrder;
    return this;
  }

  build(): CreateActivityRequest {
    if (!this.request.channelId) throw new Error('ActivityRequest: channelId is required');
    if (!this.request.name) throw new Error('ActivityRequest: name is required');
    if (!this.request.activityType) throw new Error('ActivityRequest: activityType is required');
    return this.request as CreateActivityRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Workflow Builder
// ─────────────────────────────────────────────────────────────────────────────

export class WorkflowRequestBuilder {
  private request: Partial<CreateWorkflowRequest> = {};

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  withVersion(version: string): this {
    this.request.version = version;
    return this;
  }

  fromDomainModel(workflow: Workflow): this {
    this.request.name = workflow.name;
    this.request.description = workflow.description;
    this.request.version = workflow.version;
    return this;
  }

  build(): CreateWorkflowRequest {
    if (!this.request.name) throw new Error('WorkflowRequest: name is required');
    return this.request as CreateWorkflowRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Workflow Activity Builder
// ─────────────────────────────────────────────────────────────────────────────

export class WorkflowActivityRequestBuilder {
  private request: Partial<AddWorkflowActivityRequest> = {};

  withWorkflowId(workflowId: string): this {
    this.request.workflowId = workflowId;
    return this;
  }

  withActivityId(activityId: string): this {
    this.request.activityId = activityId;
    return this;
  }

  withStepOrder(stepOrder: number): this {
    this.request.stepOrder = stepOrder;
    return this;
  }

  build(): AddWorkflowActivityRequest {
    if (!this.request.workflowId) throw new Error('WorkflowActivityRequest: workflowId is required');
    if (!this.request.activityId) throw new Error('WorkflowActivityRequest: activityId is required');
    if (this.request.stepOrder === undefined) throw new Error('WorkflowActivityRequest: stepOrder is required');
    return this.request as AddWorkflowActivityRequest;
  }
}
