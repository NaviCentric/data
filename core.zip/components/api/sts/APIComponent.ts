/**
 * API Execution Component — STS
 * Layer 4: API Components using Playwright API Testing
 *
 * Responsibilities:
 * - HTTP request/response handling for STS2 endpoints
 * - Request builders
 * - Contract validation against STS2 Swagger/OpenAPI
 * - Business rule validation
 * - Authorization/Authentication validation
 */

import { APIRequestContext } from '@playwright/test';
import { logger } from '../../../core/logger/index.js';

export class APIComponent {
  protected logger = logger;

  constructor(protected apiContext: APIRequestContext) {
    this.logger.info('Initializing component: API (STS)');
  }

  async get(url: string, options?: Record<string, unknown>): Promise<unknown> {
    logger.info(`GET: ${url}`);
    const response = await this.apiContext.get(url, options as never);
    return response.json();
  }

  async post(url: string, payload: unknown, options?: Record<string, unknown>): Promise<unknown> {
    logger.info(`POST: ${url}`);
    const response = await this.apiContext.post(url, {
      data: payload,
      ...options,
    } as never);
    return response.json();
  }

  async put(url: string, payload: unknown, options?: Record<string, unknown>): Promise<unknown> {
    logger.info(`PUT: ${url}`);
    const response = await this.apiContext.put(url, {
      data: payload,
      ...options,
    } as never);
    return response.json();
  }

  async delete(url: string, options?: Record<string, unknown>): Promise<void> {
    logger.info(`DELETE: ${url}`);
    await this.apiContext.delete(url, options as never);
  }
}
