/**
 * STS API Component Index
 */

export { APIComponent } from './APIComponent.js';

export { ChannelClient } from './clients/ChannelClient.js';
export { ActivityClient } from './clients/ActivityClient.js';
export { WorkflowClient } from './clients/WorkflowClient.js';

export {
  ChannelRequestBuilder,
  ActivityRequestBuilder,
  WorkflowRequestBuilder,
  WorkflowActivityRequestBuilder,
} from './builders/RequestBuilders.js';

export type {
  ApiErrorContract,
  ApiListResponse,
  ChannelResponse,
  CreateChannelRequest,
  UpdateChannelRequest,
  ActivityResponse,
  CreateActivityRequest,
  UpdateActivityRequest,
  WorkflowResponse,
  WorkflowActivityResponse,
  CreateWorkflowRequest,
  UpdateWorkflowRequest,
  AddWorkflowActivityRequest,
} from './contracts/ApiContracts.js';
