/**
 * API Component Index
 * Exports per-application API namespaces: ves2, sts
 */

export * as ves2 from './ves2/index.js';
export * as sts from './sts/index.js';
