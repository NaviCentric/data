/**
 * VES2 API Contracts
 * TypeScript interfaces representing the VES2 API wire format (request/response shapes).
 * Derived from VES2 Swagger/OpenAPI specifications.
 *
 * Contracts differ from Domain Models:
 *   Domain Models  = business language, used across all framework layers
 *   Contracts      = API wire format, used only in the API component layer
 */

// ─────────────────────────────────────────────────────────────────────────────
// Shared
// ─────────────────────────────────────────────────────────────────────────────

export interface ApiErrorContract {
  statusCode: number;
  message: string;
  errors?: string[];
}

export interface ApiListResponse<T> {
  items: T[];
  totalCount: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Project
// ─────────────────────────────────────────────────────────────────────────────

export interface ProjectResponse {
  projectId: string;
  name: string;
  description?: string;
  status: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateProjectRequest {
  name: string;
  description?: string;
  status?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Outing
// ─────────────────────────────────────────────────────────────────────────────

export interface OutingGroupResponse {
  outingGroupId: string;
  projectId: string;
  name: string;
  description?: string;
  status: string;
}

export interface OutingResponse {
  outingId: string;
  outingGroupId: string;
  name: string;
  description?: string;
  startDate?: string;
  endDate?: string;
  status: string;
}

export interface CreateOutingRequest {
  outingGroupId: string;
  name: string;
  description?: string;
  startDate?: string;
  endDate?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Vehicle
// ─────────────────────────────────────────────────────────────────────────────

export interface VehicleResponse {
  vehicleId: string;
  outingId: string;
  vin: string;
  make: string;
  model: string;
  year: number;
  status: string;
}

export interface CreateVehicleRequest {
  outingId: string;
  vin: string;
  make: string;
  model: string;
  year: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// Part
// ─────────────────────────────────────────────────────────────────────────────

export interface PartResponse {
  partId: string;
  assemblyId: string;
  name: string;
  partNumber: string;
  description?: string;
  status: string;
}

export interface CreatePartRequest {
  assemblyId: string;
  name: string;
  partNumber: string;
  description?: string;
}

export interface PartAttributeResponse {
  partAttributeId: string;
  partId: string;
  attributeName: string;
  attributeValue: string;
}
