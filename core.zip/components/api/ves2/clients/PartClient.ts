/**
 * VES2 Part Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type { PartResponse, CreatePartRequest, ApiListResponse } from '../contracts/ApiContracts.js';
import type { Part } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class PartClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/parts`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }


  async getAll(): Promise<Part[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<PartResponse>;
    return data.items.map(this.toModel);
  }

  async getByAssembly(assemblyId: string): Promise<Part[]> {
    const data = await this.get(`${this.baseUrl}?assemblyId=${assemblyId}`) as ApiListResponse<PartResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Part> {
    const data = await this.get(`${this.baseUrl}/${id}`) as PartResponse;
    return this.toModel(data);
  }

  async create(request: CreatePartRequest): Promise<Part> {
    const data = await this.post(this.baseUrl, request) as PartResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  private toModel(response: PartResponse): Part {
    return {
      id: response.partId,
      assemblyId: response.assemblyId,
      name: response.name,
      partNumber: response.partNumber,
      description: response.description,
      status: response.status as Part['status'],
    };
  }
}
