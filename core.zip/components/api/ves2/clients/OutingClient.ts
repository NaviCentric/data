/**
 * VES2 Outing Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type { OutingGroupResponse, OutingResponse, CreateOutingRequest, ApiListResponse } from '../contracts/ApiContracts.js';
import type { OutingGroup, Outing } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class OutingGroupClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/outing-groups`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }


  async getAll(): Promise<OutingGroup[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<OutingGroupResponse>;
    return data.items.map(this.toModel);
  }

  async getByProject(projectId: string): Promise<OutingGroup[]> {
    const data = await this.get(`${this.baseUrl}?projectId=${projectId}`) as ApiListResponse<OutingGroupResponse>;
    return data.items.map(this.toModel);
  }

  private toModel(response: OutingGroupResponse): OutingGroup {
    return {
      id: response.outingGroupId,
      projectId: response.projectId,
      name: response.name,
      description: response.description,
      status: response.status as OutingGroup['status'],
    };
  }
}

export class OutingClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/outings`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }


  async getAll(): Promise<Outing[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<OutingResponse>;
    return data.items.map(this.toModel);
  }

  async getByOutingGroup(outingGroupId: string): Promise<Outing[]> {
    const data = await this.get(`${this.baseUrl}?outingGroupId=${outingGroupId}`) as ApiListResponse<OutingResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Outing> {
    const data = await this.get(`${this.baseUrl}/${id}`) as OutingResponse;
    return this.toModel(data);
  }

  async create(request: CreateOutingRequest): Promise<Outing> {
    const data = await this.post(this.baseUrl, request) as OutingResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  private toModel(response: OutingResponse): Outing {
    return {
      id: response.outingId,
      outingGroupId: response.outingGroupId,
      name: response.name,
      description: response.description,
      startDate: response.startDate ? new Date(response.startDate) : undefined,
      endDate: response.endDate ? new Date(response.endDate) : undefined,
      status: response.status as Outing['status'],
    };
  }
}
