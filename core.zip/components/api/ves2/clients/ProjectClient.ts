/**
 * VES2 Project Service Client
 */

import { APIComponent } from '../APIComponent.js';
import type { APIRequestContext } from '@playwright/test';
import type { ProjectResponse, CreateProjectRequest, ApiListResponse } from '../contracts/ApiContracts.js';
import type { Project } from '../../../../domain/models/index.js';
import { config } from '../../../../core/config/index.js';

export class ProjectClient extends APIComponent {
  private baseUrl = `${config.apiBaseUrl}/api/projects`;

  constructor(apiContext: APIRequestContext) {
    super(apiContext);
  }

  async getAll(): Promise<Project[]> {
    const data = await this.get(this.baseUrl) as ApiListResponse<ProjectResponse>;
    return data.items.map(this.toModel);
  }

  async getById(id: string): Promise<Project> {
    const data = await this.get(`${this.baseUrl}/${id}`) as ProjectResponse;
    return this.toModel(data);
  }

  async create(request: CreateProjectRequest): Promise<Project> {
    const data = await this.post(this.baseUrl, request) as ProjectResponse;
    return this.toModel(data);
  }

  async deleteById(id: string): Promise<void> {
    await this.delete(`${this.baseUrl}/${id}`);
  }

  private toModel(response: ProjectResponse): Project {
    return {
      id: response.projectId,
      name: response.name,
      description: response.description,
      status: response.status as Project['status'],
      createdAt: new Date(response.createdAt),
      updatedAt: new Date(response.updatedAt),
    };
  }
}
