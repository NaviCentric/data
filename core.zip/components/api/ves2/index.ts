/**
 * VES2 API Component Index
 */

export { APIComponent } from './APIComponent.js';

export { ProjectClient } from './clients/ProjectClient.js';
export { OutingGroupClient, OutingClient } from './clients/OutingClient.js';
export { PartClient } from './clients/PartClient.js';

export {
  ProjectRequestBuilder,
  OutingRequestBuilder,
  VehicleRequestBuilder,
  PartRequestBuilder,
} from './builders/RequestBuilders.js';

export type {
  ApiErrorContract,
  ApiListResponse,
  ProjectResponse,
  CreateProjectRequest,
  OutingGroupResponse,
  OutingResponse,
  CreateOutingRequest,
  VehicleResponse,
  CreateVehicleRequest,
  PartResponse,
  CreatePartRequest,
  PartAttributeResponse,
} from './contracts/ApiContracts.js';
