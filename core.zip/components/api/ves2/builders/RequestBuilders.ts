/**
 * VES2 Request Builders
 * Fluent builders for constructing well-formed VES2 API request payloads.
 * Ensures required fields are set and maps from Domain Models to API Contracts.
 */

import type {
  CreatePartRequest,
  CreateOutingRequest,
  CreateVehicleRequest,
  CreateProjectRequest,
} from '../contracts/ApiContracts.js';
import type { Part, Outing, Vehicle, Project } from '../../../../domain/models/index.js';

// ─────────────────────────────────────────────────────────────────────────────
// Project Builder
// ─────────────────────────────────────────────────────────────────────────────

export class ProjectRequestBuilder {
  private request: Partial<CreateProjectRequest> = {};

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  fromDomainModel(project: Project): this {
    this.request.name = project.name;
    this.request.description = project.description;
    this.request.status = project.status;
    return this;
  }

  build(): CreateProjectRequest {
    if (!this.request.name) throw new Error('ProjectRequest: name is required');
    return this.request as CreateProjectRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Outing Builder
// ─────────────────────────────────────────────────────────────────────────────

export class OutingRequestBuilder {
  private request: Partial<CreateOutingRequest> = {};

  withOutingGroupId(id: string): this {
    this.request.outingGroupId = id;
    return this;
  }

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  withDates(startDate: Date, endDate?: Date): this {
    this.request.startDate = startDate.toISOString();
    if (endDate) this.request.endDate = endDate.toISOString();
    return this;
  }

  fromDomainModel(outing: Outing): this {
    this.request.outingGroupId = outing.outingGroupId;
    this.request.name = outing.name;
    this.request.description = outing.description;
    if (outing.startDate) this.request.startDate = outing.startDate.toISOString();
    if (outing.endDate) this.request.endDate = outing.endDate.toISOString();
    return this;
  }

  build(): CreateOutingRequest {
    if (!this.request.outingGroupId) throw new Error('OutingRequest: outingGroupId is required');
    if (!this.request.name) throw new Error('OutingRequest: name is required');
    return this.request as CreateOutingRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Vehicle Builder
// ─────────────────────────────────────────────────────────────────────────────

export class VehicleRequestBuilder {
  private request: Partial<CreateVehicleRequest> = {};

  withOutingId(id: string): this {
    this.request.outingId = id;
    return this;
  }

  withVin(vin: string): this {
    this.request.vin = vin;
    return this;
  }

  withMakeModelYear(make: string, model: string, year: number): this {
    this.request.make = make;
    this.request.model = model;
    this.request.year = year;
    return this;
  }

  fromDomainModel(vehicle: Vehicle): this {
    this.request.outingId = vehicle.outingId;
    this.request.vin = vehicle.vin;
    this.request.make = vehicle.make;
    this.request.model = vehicle.model;
    this.request.year = vehicle.year;
    return this;
  }

  build(): CreateVehicleRequest {
    if (!this.request.outingId) throw new Error('VehicleRequest: outingId is required');
    if (!this.request.vin) throw new Error('VehicleRequest: vin is required');
    return this.request as CreateVehicleRequest;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Part Builder
// ─────────────────────────────────────────────────────────────────────────────

export class PartRequestBuilder {
  private request: Partial<CreatePartRequest> = {};

  withAssemblyId(id: string): this {
    this.request.assemblyId = id;
    return this;
  }

  withName(name: string): this {
    this.request.name = name;
    return this;
  }

  withPartNumber(partNumber: string): this {
    this.request.partNumber = partNumber;
    return this;
  }

  withDescription(description: string): this {
    this.request.description = description;
    return this;
  }

  fromDomainModel(part: Part): this {
    this.request.assemblyId = part.assemblyId;
    this.request.name = part.name;
    this.request.partNumber = part.partNumber;
    this.request.description = part.description;
    return this;
  }

  build(): CreatePartRequest {
    if (!this.request.assemblyId) throw new Error('PartRequest: assemblyId is required');
    if (!this.request.name) throw new Error('PartRequest: name is required');
    if (!this.request.partNumber) throw new Error('PartRequest: partNumber is required');
    return this.request as CreatePartRequest;
  }
}
