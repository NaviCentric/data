/**
 * Component Factory
 * Single composition root for tests.
 *
 * Tests receive one `components` object and access:
 *   components.ui
 *   components.api
 *   components.db
 *   components.desktop
 */

import type { APIRequestContext, Page } from '@playwright/test';
import { UiFactory, type UiComponents } from './UiFactory.js';
import { ApiFactory, type ApiComponents } from './ApiFactory.js';
import { DbFactory, type DbComponents } from './DbFactory.js';
import { DesktopFactory, type DesktopComponents } from './DesktopFactory.js';

export interface ComponentSuite {
  ui: UiComponents;
  api: ApiComponents;
  db: DbComponents;
  desktop: DesktopComponents;
}

export class ComponentFactory {
  constructor(
    private readonly page: Page,
    private readonly request: APIRequestContext
  ) {}

  create(): ComponentSuite {
    return {
      ui: new UiFactory(this.page).create(),
      api: new ApiFactory(this.request).create(),
      db: new DbFactory().create(),
      desktop: new DesktopFactory().create(),
    };
  }
}
