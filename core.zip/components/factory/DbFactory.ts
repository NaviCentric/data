/**
 * DB Factory
 * Creates repositories, query access, and stored procedure placeholders.
 */

import { DatabaseRepository } from '../database/DatabaseRepository.js';
import { ProjectRepository } from '../database/repositories/ProjectRepository.js';
import { OutingGroupRepository, OutingRepository } from '../database/repositories/OutingRepository.js';
import { VehicleRepository } from '../database/repositories/VehicleRepository.js';
import {
  AssemblyRepository,
  PartRepository,
  PartAttributeRepository,
  AssemblyAttributeRepository,
} from '../database/repositories/PartRepository.js';
import {
  ProjectQueries,
  OutingGroupQueries,
  OutingQueries,
  VehicleQueries,
  AssemblyQueries,
  PartQueries,
  PartAttributeQueries,
  AssemblyAttributeQueries,
} from '../database/index.js';
import { StoredProcedures } from '../database/procedures/StoredProcedures.js';

export interface DbRepositories {
  base: DatabaseRepository;
  project: ProjectRepository;
  outingGroup: OutingGroupRepository;
  outing: OutingRepository;
  vehicle: VehicleRepository;
  assembly: AssemblyRepository;
  part: PartRepository;
  partAttribute: PartAttributeRepository;
  assemblyAttribute: AssemblyAttributeRepository;
}

export interface DbComponents {
  repositories: DbRepositories;
  queries: {
    project: typeof ProjectQueries;
    outingGroup: typeof OutingGroupQueries;
    outing: typeof OutingQueries;
    vehicle: typeof VehicleQueries;
    assembly: typeof AssemblyQueries;
    part: typeof PartQueries;
    partAttribute: typeof PartAttributeQueries;
    assemblyAttribute: typeof AssemblyAttributeQueries;
  };
  procedures: typeof StoredProcedures;
}

export class DbFactory {
  create(): DbComponents {
    return {
      repositories: {
        base: new DatabaseRepository(),
        project: new ProjectRepository(),
        outingGroup: new OutingGroupRepository(),
        outing: new OutingRepository(),
        vehicle: new VehicleRepository(),
        assembly: new AssemblyRepository(),
        part: new PartRepository(),
        partAttribute: new PartAttributeRepository(),
        assemblyAttribute: new AssemblyAttributeRepository(),
      },
      queries: {
        project: ProjectQueries,
        outingGroup: OutingGroupQueries,
        outing: OutingQueries,
        vehicle: VehicleQueries,
        assembly: AssemblyQueries,
        part: PartQueries,
        partAttribute: PartAttributeQueries,
        assemblyAttribute: AssemblyAttributeQueries,
      },
      procedures: StoredProcedures,
    };
  }
}
