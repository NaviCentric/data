/**
 * UI Factory — VES2
 * Creates web pages and Wijmo fragments for the VES2 application.
 */

import type { Page } from '@playwright/test';
import { LoginPage } from '../web/ves2/pages/LoginPage.js';
import { ProjectsPage } from '../web/ves2/pages/ProjectsPage.js';
import { OutingPage } from '../web/ves2/pages/OutingPage.js';
import { WijmoGridFragment } from '../web/ves2/fragments/WijmoGridFragment.js';
import { WijmoComboFragment } from '../web/ves2/fragments/WijmoComboFragment.js';
import { WijmoInputFragment } from '../web/ves2/fragments/WijmoInputFragment.js';

export interface UiPages {
  login: LoginPage;
  projects: ProjectsPage;
  outing: OutingPage;
}

export interface UiFragments {
  grid: WijmoGridFragment;
  combo: WijmoComboFragment;
  input: WijmoInputFragment;
}

export interface UiComponents {
  pages: UiPages;
  fragments: UiFragments;
}

export class UiFactory {
  constructor(private readonly page: Page) {}

  create(): UiComponents {
    return {
      pages: {
        login: new LoginPage(this.page),
        projects: new ProjectsPage(this.page),
        outing: new OutingPage(this.page),
      },
      fragments: {
        grid: new WijmoGridFragment(this.page, '[data-grid="reference"]'),
        combo: new WijmoComboFragment(this.page, '[data-control="reference-combo"]'),
        input: new WijmoInputFragment(this.page, '[data-control="reference-input"]'),
      },
    };
  }
}
