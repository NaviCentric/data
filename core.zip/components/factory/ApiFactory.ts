/**
 * API Factory
 * Creates service clients and request builders for VES2 and STS applications.
 */

import type { APIRequestContext } from '@playwright/test';

// VES2
import { ProjectClient } from '../api/ves2/clients/ProjectClient.js';
import { OutingClient, OutingGroupClient } from '../api/ves2/clients/OutingClient.js';
import { PartClient } from '../api/ves2/clients/PartClient.js';
import {
  ProjectRequestBuilder,
  OutingRequestBuilder,
  VehicleRequestBuilder,
  PartRequestBuilder,
} from '../api/ves2/builders/RequestBuilders.js';

// STS
import { ChannelClient } from '../api/sts/clients/ChannelClient.js';
import { ActivityClient } from '../api/sts/clients/ActivityClient.js';
import { WorkflowClient } from '../api/sts/clients/WorkflowClient.js';
import {
  ChannelRequestBuilder,
  ActivityRequestBuilder,
  WorkflowRequestBuilder,
  WorkflowActivityRequestBuilder,
} from '../api/sts/builders/RequestBuilders.js';

// ─── VES2 ────────────────────────────────────────────────────────────────────

export interface Ves2ApiClients {
  project: ProjectClient;
  outing: OutingClient;
  outingGroup: OutingGroupClient;
  part: PartClient;
}

export interface Ves2ApiBuilders {
  project: ProjectRequestBuilder;
  outing: OutingRequestBuilder;
  vehicle: VehicleRequestBuilder;
  part: PartRequestBuilder;
}

export interface Ves2ApiComponents {
  clients: Ves2ApiClients;
  builders: Ves2ApiBuilders;
}

// ─── STS ─────────────────────────────────────────────────────────────────────

export interface StsApiClients {
  channel: ChannelClient;
  activity: ActivityClient;
  workflow: WorkflowClient;
}

export interface StsApiBuilders {
  channel: ChannelRequestBuilder;
  activity: ActivityRequestBuilder;
  workflow: WorkflowRequestBuilder;
  workflowActivity: WorkflowActivityRequestBuilder;
}

export interface StsApiComponents {
  clients: StsApiClients;
  builders: StsApiBuilders;
}

// ─── Combined ────────────────────────────────────────────────────────────────

export interface ApiComponents {
  ves2: Ves2ApiComponents;
  sts: StsApiComponents;
}

export class ApiFactory {
  constructor(private readonly request: APIRequestContext) {}

  create(): ApiComponents {
    return {
      ves2: {
        clients: {
          project: new ProjectClient(this.request),
          outing: new OutingClient(this.request),
          outingGroup: new OutingGroupClient(this.request),
          part: new PartClient(this.request),
        },
        builders: {
          project: new ProjectRequestBuilder(),
          outing: new OutingRequestBuilder(),
          vehicle: new VehicleRequestBuilder(),
          part: new PartRequestBuilder(),
        },
      },
      sts: {
        clients: {
          channel: new ChannelClient(this.request),
          activity: new ActivityClient(this.request),
          workflow: new WorkflowClient(this.request),
        },
        builders: {
          channel: new ChannelRequestBuilder(),
          activity: new ActivityRequestBuilder(),
          workflow: new WorkflowRequestBuilder(),
          workflowActivity: new WorkflowActivityRequestBuilder(),
        },
      },
    };
  }
}
