/**
 * Desktop Factory — STS
 * Creates desktop screens and DevExpress fragments for the STS application.
 */

import { MainWindow } from '../desktop/sts/screens/MainWindow.js';
import { ChannelsScreen } from '../desktop/sts/screens/ChannelsScreen.js';
import { ActivitiesScreen } from '../desktop/sts/screens/ActivitiesScreen.js';
import { WorkflowsScreen } from '../desktop/sts/screens/WorkflowsScreen.js';
import { DevExpressGridFragment } from '../desktop/sts/fragments/DevExpressGridFragment.js';
import { DevExpressComboFragment } from '../desktop/sts/fragments/DevExpressComboFragment.js';
import { DevExpressTabFragment } from '../desktop/sts/fragments/DevExpressTabFragment.js';

export interface DesktopScreens {
  mainWindow: MainWindow;
  channels: ChannelsScreen;
  activities: ActivitiesScreen;
  workflows: WorkflowsScreen;
}

export interface DesktopFragments {
  grid: DevExpressGridFragment;
  combo: DevExpressComboFragment;
  tab: DevExpressTabFragment;
}

export interface DesktopComponents {
  screens: DesktopScreens;
  fragments: DesktopFragments;
}

export class DesktopFactory {
  create(): DesktopComponents {
    return {
      screens: {
        mainWindow: new MainWindow(),
        channels: new ChannelsScreen(),
        activities: new ActivitiesScreen(),
        workflows: new WorkflowsScreen(),
      },
      fragments: {
        grid: new DevExpressGridFragment('ReferenceGrid'),
        combo: new DevExpressComboFragment('ReferenceCombo'),
        tab: new DevExpressTabFragment('ReferenceTab'),
      },
    };
  }
}
