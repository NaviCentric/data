/**
 * Desktop UI Component Index
 * Exports per-application desktop namespaces: sts
 */

export * as sts from './sts/index.js';
