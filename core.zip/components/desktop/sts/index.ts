/**
 * STS Desktop Component Index
 */

export { DesktopUIComponent } from './DesktopUIComponent.js';
export * from './screens/index.js';
export * from './fragments/index.js';
