/**
 * DevExpress ComboBox Fragment
 * Reference: DevExpressGridFragment.ts
 */

export class DevExpressComboFragment {
  constructor(private automationId: string) {}

  async selectByText(text: string): Promise<void> {
    // TODO
    void text;
  }

  async selectByIndex(index: number): Promise<void> {
    // TODO
    void index;
  }

  async getSelectedText(): Promise<string> {
    // TODO
    return '';
  }
}
