/**
 * STS Desktop Fragments Index
 */

export { DevExpressGridFragment } from './DevExpressGridFragment.js';
export { DevExpressComboFragment } from './DevExpressComboFragment.js';
export { DevExpressTabFragment } from './DevExpressTabFragment.js';
