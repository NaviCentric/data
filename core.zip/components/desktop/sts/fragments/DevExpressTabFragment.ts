/**
 * DevExpress Tab Fragment
 * Reference: DevExpressGridFragment.ts
 */

export class DevExpressTabFragment {
  constructor(private automationId: string) {}

  async selectTab(tabTitle: string): Promise<void> {
    // TODO
    void tabTitle;
  }

  async getActiveTabTitle(): Promise<string> {
    // TODO
    return '';
  }

  async getTabTitles(): Promise<string[]> {
    // TODO
    return [];
  }
}
