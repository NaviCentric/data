/**
 * Main Window Screen — STS
 *
 * Entry point screen for the STS2 desktop application.
 *
 * Usage:
 *   const mainWindow = new MainWindow();
 *   await mainWindow.waitForLoad();
 *   await mainWindow.navigateTo('Channels');
 */

import { DevExpressTabFragment } from '../fragments/DevExpressTabFragment.js';

export class MainWindow {
  readonly navigationTabs: DevExpressTabFragment;

  constructor() {
    // TODO: locate main window via FlaUI Application.Launch or Attach
    this.navigationTabs = new DevExpressTabFragment('MainNavigationTabs');
  }

  async waitForLoad(): Promise<void> {
    // TODO: wait for main window automation element to appear
    // TODO: wait for loading overlay to disappear
  }

  async navigateTo(section: string): Promise<void> {
    // TODO: click navigation item matching section name
    void section;
  }

  async close(): Promise<void> {
    // TODO: send close command via FlaUI
  }

  async getTitle(): Promise<string> {
    // TODO: return window.Title via FlaUI
    return '';
  }
}
