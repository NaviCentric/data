/**
 * Activities Screen — STS
 *
 * Screen model for the STS2 Activities management screen.
 * Activities represent discrete operations assigned to channels.
 *
 * Usage:
 *   const activities = new ActivitiesScreen();
 *   await activities.waitForLoad();
 *   await activities.openActivityByName('ACT-001');
 */

import { DevExpressGridFragment } from '../fragments/DevExpressGridFragment.js';
import { DevExpressComboFragment } from '../fragments/DevExpressComboFragment.js';

export class ActivitiesScreen {
  readonly grid: DevExpressGridFragment;
  readonly channelFilter: DevExpressComboFragment;

  constructor() {
    this.grid = new DevExpressGridFragment('ActivitiesGridControl');
    this.channelFilter = new DevExpressComboFragment('ChannelFilterCombo');
  }

  async waitForLoad(): Promise<void> {
    // TODO: wait for activities grid to be visible and loaded
    await this.grid.waitForLoad();
  }

  async filterByChannel(channelName: string): Promise<void> {
    // TODO: select channel from filter combo and refresh grid
    await this.channelFilter.selectByText(channelName);
  }

  async openActivityByName(activityName: string): Promise<void> {
    // TODO: find row by activity name and double-click to open
    void activityName;
  }

  async createNewActivity(): Promise<void> {
    // TODO: click New/Add button on activities toolbar
  }

  async getActivityCount(): Promise<number> {
    return this.grid.getRowCount();
  }
}
