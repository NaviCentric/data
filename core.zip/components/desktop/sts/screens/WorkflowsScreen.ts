/**
 * Workflows Screen — STS
 *
 * Screen model for the STS2 Workflows management screen.
 * Workflows represent ordered sequences of activities.
 *
 * Usage:
 *   const workflows = new WorkflowsScreen();
 *   await workflows.waitForLoad();
 *   await workflows.openWorkflowByName('WF-001');
 */

import { DevExpressGridFragment } from '../fragments/DevExpressGridFragment.js';
import { DevExpressTabFragment } from '../fragments/DevExpressTabFragment.js';

export class WorkflowsScreen {
  readonly grid: DevExpressGridFragment;
  readonly detailTabs: DevExpressTabFragment;

  constructor() {
    this.grid = new DevExpressGridFragment('WorkflowsGridControl');
    this.detailTabs = new DevExpressTabFragment('WorkflowDetailTabs');
  }

  async waitForLoad(): Promise<void> {
    // TODO: wait for workflows grid to be visible and loaded
    await this.grid.waitForLoad();
  }

  async openWorkflowByName(workflowName: string): Promise<void> {
    // TODO: find row by workflow name and double-click to open detail panel
    void workflowName;
  }

  async createNewWorkflow(): Promise<void> {
    // TODO: click New/Add button on workflows toolbar
  }

  async getWorkflowCount(): Promise<number> {
    return this.grid.getRowCount();
  }

  async selectDetailTab(tabTitle: string): Promise<void> {
    await this.detailTabs.selectTab(tabTitle);
  }
}
