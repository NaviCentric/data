/**
 * Channels Screen — STS
 *
 * Screen model for the STS2 Channels management screen.
 * Channels represent communication paths in the STS2 system.
 *
 * Usage:
 *   const channels = new ChannelsScreen();
 *   await channels.waitForLoad();
 *   await channels.openChannelByName('CH-001');
 */

import { DevExpressGridFragment } from '../fragments/DevExpressGridFragment.js';

export class ChannelsScreen {
  readonly grid: DevExpressGridFragment;

  constructor() {
    this.grid = new DevExpressGridFragment('ChannelsGridControl');
  }

  async waitForLoad(): Promise<void> {
    // TODO: wait for channels grid to be visible and loaded
    await this.grid.waitForLoad();
  }

  async openChannelByName(channelName: string): Promise<void> {
    // TODO: find row by channel name and double-click to open
    void channelName;
  }

  async createNewChannel(): Promise<void> {
    // TODO: click New/Add button on channels toolbar
  }

  async getChannelCount(): Promise<number> {
    return this.grid.getRowCount();
  }
}
